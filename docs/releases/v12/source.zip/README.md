# eChessGw

**Current stable release: V12 — 28 October 2026.** Certabo and Tabutronic Spectrum integration confirmed by the tester. [Install V12](https://parlue.github.io/eChessGw/) · [Release](https://github.com/parlue/eChessGw/releases/tag/v12).

eChessGw is an independent source-available BLE gateway for chess
computer modules that speak the ChessLink (Mode B) protocol over a cable. It
replaces the cable between the chess computer module and a BLE-enabled
e-board with a BLE connection -- and, unlike a single-board bridge,
it scans for and connects to **whichever supported e-board is present** at
runtime, translating each board's own native protocol to and from Mode B on
the fly. One firmware image, multiple board brands.

No cable chess computer at hand? The gateway can also run
[standalone](#standalone-mode-no-cable-computer-required), masquerading as a
ChessLink or Chessnut board over BLE so wireless chess software can connect
to it directly.

```text
Generic chess computer module with DIN connector
              ⇅
        4-pin Mini-DIN
              ⇅ RS-232
       HW-027 with MAX3232
              ⇅ UART / 3.3 V
        ESP32-C3 SuperMini
              ⇅ BLE
MILLENNIUM Supreme T2 BT -- or -- Chessnut Air/GO/Pro -- or -- ManyaCynus robot -- or -- Certabo / Spectrum -- or -- iChessOne
```

<p>
  <img src="images/module-usb-c.jpg" alt="eChessGw module, USB-C side" width="300">
  <img src="images/module-minidin.jpg" alt="eChessGw module, Mini-DIN cable side" width="300">
</p>

**Full user manual (PDF):** [English](eChessGw-Manual-EN.pdf) &middot;
[Deutsch](eChessGw-Handbuch-DE.pdf)

## Supported e-boards

**V12 includes both Certabo and Spectrum in the normal release installer.**
The extra-queen layout chooses the LED driver; figures are learned again on every connection.

| Board | Status |
|---|---|
| MILLENNIUM Supreme T2 BT (and other genuine ChessLink boards) | Working -- native Mode B relayed as-is |
| Chessnut Air / GO / Pro | Working -- Chessnut's own BLE protocol translated to/from Mode B, including LED move suggestions and New Game/reset highlighting |
| ManyaCynus (camera-vision chess robot) | Working -- ManyaCynus's own line-based BLE protocol translated to/from Mode B; decodes the chess computer's own LED move suggestions and commands ManyaCynus's arm to execute them, including castling, en passant and pawn promotion |
| Certabo (Bluetooth LE / Nordic UART, mono-LED boards) | Working -- piece chips are read in at every start ([see below](#certabo--spectrum-selecting-the-board-and-learning-pieces)), then the board's own LEDs show move suggestions from a MILLENNIUM King, Mephisto Phoenix, BearChess and Chessnut clients |
| iChessOne | Untested on real hardware -- driver built from the vendor's own documented BLE protocol (Nordic UART Service), not yet confirmed against a real unit; LED colour and brightness can be chosen by gesture ([see below](#ichessone-led-colour-and-brightness)) |
| Tabutronic Spectrum / Certabo RGB | Working in V12 -- 81 RGB LEDs, blue at 80% by default; extra queens on e3/e6 select Spectrum; colour/brightness gestures available |

Board detection is automatic: on every (re)connect attempt, the gateway scans
for any known board's advertised BLE name and connects to whichever one it
finds, with no build-time board selection needed.

### Certabo / Spectrum: selecting the board and learning pieces

Use the normal 32-piece position plus two extra queens:

| Board | White extra queen | Black extra queen |
|---|---|---|
| Certabo (normal LEDs) | d3 | d6 |
| Spectrum (81 RGB LEDs) | e3 | e6 |

**Early setup LEDs:** one unique extra chip stable on either selection square
for three full scans selects the driver. Missing, extra or duplicate chips then
light after two real scans and clear immediately when corrected. All 34 unique
IDs and seven-scan majority remain required before confirmation or play.
Swapped piece types cannot be detected during initial learning. The chosen
driver then blinks the four centre squares three times; Spectrum uses blue 80%.
Remove both extra queens. Normal play starts only at the correct starting setup.

The explicit choice replaces unreliable packet-size/marker heuristics. Figure
IDs are interchangeable and never determine the model. Each connection learns
anew; archived IDs are not reused. Mixed choices stay dark before selection. Once selected, the driver stays fixed
until reconnect, and opposite choice squares are reported as setup errors.
MTU stays at 256. King/Phoenix cable processing is unchanged. V11 remains archived as a fallback.

Spectrum uses 247-byte RGB frames, four corners per square. Startup confirmation
is blue 80%; play defaults to blue 80%, with saved user gesture choices retained.
Gestures: normal position plus the white spare queen held for one second on
g3/g4/g5/g6 selects red/blue/green/orange; h3/h4/h5/h6 selects 25/50/75/100%.
Remove the queen after confirmation. The configuration is not forwarded as a move.

The tester confirmed the current Certabo/Spectrum firmware on 28 October 2026.
V12 promotes that exact tested firmware without changing its program bytes.
Its internal build timestamp therefore remains the original tested build timestamp.

**Frozen build:** `pio run -e esp32-c3-superminiV12_Spectrum`.
All project sources and headers for V12 are isolated in `src/frozen_v12/`, with
Espressif32 7.0.1 and NimBLE-Arduino 2.5.1 pinned. The ordinary
`esp32-c3-supermini` environment excludes that directory and remains the development target.
Do not edit the frozen directory for future features.

[V12 source and checksums](docs/releases/v12/), [detailed setup](docs/certabo_spectrum.md),
and [archived V11](docs/releases/v11/manifest.json).

### ManyaCynus special cases

ManyaCynus is a camera-vision robot, not a per-square sensor board, so its
driver reproduces several behaviors of a real ChessLink board rather than
having them natively. This follows the same conventions as
[CynusLink](https://github.com/parlue/CynusLink), an independent project for
the same robot that this gateway's ManyaCynus support is ported from.

- **Startup**: the scanned position is checked against the normal and
  mirrored starting position before anything else; an incorrect setup is
  rescanned automatically every 5 seconds until it matches.
- **Illegal-move check disabled automatically (firmware 1.4.2+ only)**: on
  every connect, the gateway asks Cynus for its app version and, if it's
  1.4.2 or newer, sends `set illegal move check off` -- Cynus's own
  onboard legality checking otherwise fights the gateway whenever an
  external chess computer (not Cynus's own built-in engine) is actually
  driving the game. Units on older firmware are left untouched; update
  Cynus's own firmware to get this.
- **Options via the black King**: with the board in its starting position,
  moving only the black King onto one of the following squares toggles a
  setting instead of being treated as a move -- move it back to its home
  square (or the option's own "off" square) to leave the option again:

  | Black King square | Function |
  |---|---|
  | b5 / b6 | Board-orientation flip on / off |
  | c5 / c6 | Set Position mode on / off |
  | d5 / d6 | Free Analysis mode on / off |
  | e5 / e6 | Sound off / on |

  Board-orientation flip is now **only** ever set this way -- there is no
  automatic "the scan looks flipped, so flip must be on" detection any
  more. That heuristic broke as soon as software could drive both colors
  of a game over the LED channel with no scan at all (a pure PGN/game
  replay): a first move relayed by the software has no fixed relationship
  to which color is actually being replayed, and a genuinely flipped
  ManyaCynus can still report a normal-looking scan anyway (its own
  scanning layer compensates), so pattern-matching a scan was never a
  reliable signal either way. Flip the board manually with the gesture
  above if you need it.

- **Free Analysis mode**: while active, every scanned position is forwarded
  to the chess computer as-is, without checking it's a legal move -- the
  board is re-scanned automatically every 5 seconds. The connected chess
  software also needs its own support for this mode.
- **Castling, en passant and promotion**: reported to the chess computer as
  the individual piece lift/place steps a physical board would produce
  (e.g. king lifted, king placed, rook lifted, rook placed for castling),
  not as a single jump to the final position.
- **Display**: ManyaCynus's own screen shows the last move made (e.g.
  "E2-E4", "0-0" for castling), "POS OK" once the starting position is
  confirmed, and the specific offending square(s) (e.g. "+E4") when a scan
  doesn't settle into a legal position.
- **Driven live by a connected Chessnut app** (standalone mode, Chessnut
  masquerade): for normal human-vs-computer play, the connected app's
  engine-move commands are decoded and sent straight to ManyaCynus's own
  robot arm to execute -- confirmed against Chess Dojo. The same command is
  also used by at least one client to echo a move it just saw the human
  make by hand; that echo is recognized (it's textually identical to the
  human move the gateway itself just detected) and never re-executed, so
  the robot only ever moves for the computer's own side. Not used for a
  "bot plays both sides" self-play/replay mode, and inactive while Free
  Analysis or Set Position is active.
- **Recovering from an unexpected reconnect**: if ManyaCynus loses its BLE
  connection mid-game (e.g. it resets itself) and reconnects, the gateway
  would normally insist on seeing the exact starting position again before
  resuming, blocking the game in progress. Lifting both Kings off the board
  at any point -- right after reconnecting, or even mid-game -- arms a
  manual override instead: the display shows "newpos", automatic rescanning
  stops, and the gateway waits (no time limit) for the desired position to
  be rebuilt. Once both Kings are back on the board, press ManyaCynus's own
  Clock/Scan button to submit that position as-is, no legality check --
  exactly what a real chess computer's own "set up position" mode expects.

### Certabo: reading in the pieces

A Certabo board identifies every piece by a chip ID, not by piece type. The
gateway cannot know which chip is a queen, a rook or a pawn, so it has to
**read in all 34 chips every time the gateway is started** (a short BLE
reconnect to the same board keeps what was learned; a restart does not).
Do this once after switching the gateway on and the Certabo has connected:

1. Set up all 32 pieces in the normal starting position, White on ranks 1
   and 2. Every piece must stand on its correct starting square -- the
   software cannot tell afterwards what an unlearned chip is.
2. Put the **second (spare) white queen on d3** and the **second (spare)
   black queen on d6**. Both are required: the gateway needs 34 chips.
3. While the position is being checked, the board's own LEDs light every
   square that is still wrong (a missing piece, a piece on a wrong square,
   or a chip that appears twice). Correct those squares until no LED
   remains lit.
4. When all 34 chips are read in and saved, the four centre squares **d4,
   e4, d5 and e5 blink three times together**. That blinking is the
   confirmation that the pieces are learned.
5. **d3 and d6 stay lit** until the two spare queens are lifted off; each
   LED goes out when its queen leaves. After that the board is ready and
   behaves like any other supported e-board.

A position with an unknown or duplicated chip is never taken for an empty
square -- it is held back, so a loose or wrong piece cannot cause a wrong
move.

**Choosing the protocol (standalone mode):** the Certabo has no automatic
selection, so the gesture is used. Once the centre squares have signalled
that the board is ready, place the spare white queen **on a4 for
ChessLink** (BearChess, Chess Dojo) or **on b4 for Chessnut** (Chess PGN
Master and other Chessnut clients). Place it directly on its square and
leave it there for a moment -- sliding it across a4 on the way to b4 can
select ChessLink instead. The four corner squares a1, h1, a8 and h8 light
for 3 seconds to confirm; then take the queen off the board again.

**LEDs on the Certabo:** the board shows the move suggestion of a connected
chess computer (a MILLENNIUM King or Mephisto Phoenix on the cable) or of a
wireless client. With a King, the human's own move is also shown for half a
second (both squares), and the King's suggestion stays lit until it is
played. A Phoenix's blinking suggestion is mirrored as it arrives.

### iChessOne: LED colour and brightness

The iChessOne is found by its BLE name `iChessOne` (Nordic UART Service). It has
two LEDs per square; the board's own firmware handles that, so the gateway only
names the squares to light. All squares light in **one steady colour** (red at
75 % brightness by default). The colour and the brightness can be changed with a
gesture on the starting position, without any app:

1. Set up the normal starting position (all 32 pieces).
2. Put **one extra white queen** on one of the squares below and leave it there
   for about a second.

| Square | Setting |
|---|---|
| g3 | Colour **red** (default) |
| g4 | Colour **blue** |
| g5 | Colour **green** |
| g6 | Colour **orange** |
| h3 | Brightness **25 %** |
| h4 | Brightness **50 %** |
| h5 | Brightness **75 %** (default) |
| h6 | Brightness **100 %** |

As confirmation the four centre squares **d4, e4, d5 and e5 blink three times**
in the new setting (the board does the blinking itself). The choice is stored in
the gateway and kept after a restart. Take the extra queen off the board again
afterwards. The gesture does not interfere with the standalone-mode queen
gesture on a4/b4. Colour and brightness are independent: set one, then the
other. (g7 is not used -- it is occupied on the starting position.)

**Status:** included in V12. Like the whole iChessOne driver it has not
been tested on a real board yet, and the exact look of the orange and of the
brightness steps depends on the board's LEDs.

## Startup sequence

Follow this order every time, especially when using a Mephisto Phoenix or
Chess Element module -- both can take a few seconds to boot, and the gateway
only gets one look at the cable during that window:

1. **Make sure the USB port has no power on it.** Don't have the gateway
   powered from USB (e.g. still plugged into a computer or power bank) at
   the same time it's powered from the chess computer module's cable -- power
   the gateway from the module only, exactly as the [wiring diagram](#power)
   describes.
2. Power on the chess computer module and **wait until it has fully booted**
   before doing anything else.
3. **Only then** switch on the e-board (Chessnut, MILLENNIUM Supreme T2 BT,
   ManyaCynus, etc.).

If the module is unusually slow to boot and the gateway's own 5-second cable
check elapses first, it falls back to [standalone mode](#standalone-mode-no-cable-computer-required)
as described below -- but this is self-correcting: as soon as the gateway
sees any data arrive on the cable after that, even minutes later, it
automatically drops any standalone BLE-to-BLE connection and restarts itself
into normal cable mode. No manual power cycle is needed to recover from a
slow-booting module.

## Standalone mode (no cable computer required)

If no chess computer module is detected on the cable within 5 seconds of
power-up, the gateway switches into a standalone mode: it keeps its normal
BLE connection to the e-board, and **additionally** starts advertising itself
as a BLE peripheral -- masquerading as either a genuine ChessLink board or a
genuine Chessnut board -- so wireless chess software can connect directly to
the gateway with no chess computer module in the loop at all. As covered
under [Startup sequence](#startup-sequence) above, this is automatically
undone (with a self-restart back into normal cable mode) the moment cable
data is later detected, so it's safe even if a module just happened to boot
slowly rather than being genuinely absent.

**Automatic protocol selection (firmware change, 6 October 2026):** in
standalone operation, the gateway selects the other board protocol once
the connected board has supplied its first valid position:

| Connected e-board | Gateway advertises as | Selection gesture |
|---|---|---|
| Chessnut Air / GO / Pro | **MILLENNIUM CHESS** — ChessLink BLE | None |
| MILLENNIUM / Supreme T2 | **Chessnut Air** — Chessnut BLE | None |
| Other supported board types | ChessLink or Chessnut BLE | Second white queen on a4 or b4, as below |

This selection remains available in the V12 firmware published in the web installer.
The Certabo gesture path has been confirmed on real hardware; the automatic
selection for Chessnut and MILLENNIUM boards has not been separately
confirmed since this change.

**Setup sequence** (signalled on the connected e-board itself — LED
squares on Millennium/Chessnut boards, text on ManyaCynus):

1. The gateway connects to the e-board and receives its first valid board
   position.
2. **Ready signal**: the four center squares (d4/d5/e4/e5) light up
   (ManyaCynus: "OK") for 3 seconds, then clear.
3. **Chessnut and Millennium boards:** selection is automatic according
   to the table above. Do not place an extra queen to select a protocol.
   **Other supported board types:** place a second white queen on
   **a4** for ChessLink ("MILLENNIUM CHESS") or **b4** for Chessnut
   ("Chessnut Air").
4. **Confirmed signal**: the four corner squares light up (ManyaCynus:
   "ChessL" / "Chnut") for 3 seconds, then clear, and the selected
   protocol starts advertising.
5. Connect to the gateway from your chess software as you would to a real
   board of the advertised type.

**The cable chess computer always takes priority.** Automatic selection
runs only in standalone mode. If cable data arrives later, including
during setup or after a BLE app has connected, the existing restart
mechanism resets the standalone selection and BLE connections and reruns
cable detection. The selection is not saved persistently. Other gestures
and the engine-vs-engine setup are unchanged.

| Masquerade | Confirmed working with |
|---|---|
| ChessLink ("MILLENNIUM CHESS") | PicoChess, [BearChess](https://www.solanosoft.com/index.php?page=bearchess), and at least one other independent ChessLink client |
| Chessnut ("Chessnut Air") | [Chess PGN Master](https://pgnmaster.kalab.com/), [BearChess](https://www.solanosoft.com/index.php?page=bearchess) |

This mode is independent of, and doesn't change, normal cable operation --
if a chess computer module is present on the cable at power-up, standalone
mode never activates.

## Engine vs. engine (with or without an e-board)

The two engine-vs-engine operating modes are implemented and ready to use
with the matching current firmware:

| Mode | How moves are carried out |
|---|---|
| **With an e-board** | A person follows the move indications on a sensor board, or ManyaCynus executes them with its robot arm. The actual board confirms the position. |
| **Without an e-board** | The gateway maintains a virtual board and supplies the piece lift/place sequence to both computers automatically. EChessTool provides the wireless New Game button. |

Both modes connect a **cable-connected King or Mephisto Phoenix** to
**BLE ChessLink software**, such as BearChess or another compatible GUI/app.
Both computers see a ChessLink/T2-style board; neither needs a special
EChessTool command or plugin.

**Status, 2 October 2026:** both modes are complete for the established
workflow. The boardless workflow has also been confirmed with the Android
app: Connect, New Game, reversing the colours and playing the next game.
This does not imply that every board/app combination has been tested.
Use firmware that includes these features; the published v9.3 web-installer
image must not be assumed to contain them.

### Connecting — follow this order

1. **Boot the Phoenix or King first.** Connect the gateway by cable using
   the power arrangement in [Startup sequence](#startup-sequence). Wait
   until the chess computer is fully booted and ready to play. Leave the
   optional e-board switched off for now.
2. **Connect the other chess software next.** Select **ChessLink BLE** in
   BearChess or another compatible GUI/app and connect to **MILLENNIUM
   CHESS**. Wait for the connection to complete. No queen gesture is needed.
3. **For physical-board mode, switch on the known e-board now.** Wait for
   its connection and the standard starting position to be recognized,
   before either engine makes its first move.
4. **For boardless mode, leave the e-board off.** Wait for the virtual
   starting position supplied by the gateway.
5. Configure one computer to play White and the other Black, then start
   engine play. Either colour assignment is supported: the first legal
   opening move determines which side plays White.

With a sensor board, carry out each indicated move and let the board report
the resulting position. With ManyaCynus, wait for the robot to execute and
confirm the move. Only confirmed positions advance the physical-board game.

**Connection order matters:** if a real e-board connects before the
software, the gateway selects normal cable-to-board operation instead.
After the software connects first, an optional board can still be selected
until the first virtual move. Once virtual play starts, adding a playing
board requires a gateway restart. A board disconnect never silently
changes an established physical-board session into a virtual game.

### EChessTool: New Game without a physical board

**EChessTool** is the Android companion app, previously named **Newgame
Button**. It acts as a wireless button, not as a chess engine or game viewer.
Android APKs are provided in the [Android folder](Android); older builds
may still carry the previous filename. The app requires Android 8 or newer
and a phone that supports BLE peripheral advertising.

The phone advertises its own BLE service; the gateway discovers and
connects to it. This control connection is separate from the connection to
the playing chess software.

1. End or stop the current game and prepare a new game on both chess
   computers/programs. Choose the desired colours.
2. Open **EChessTool** and tap **Connect**. Allow the Nearby devices
   permission when Android asks. The button is red while disconnected or
   waiting, and turns **green** when the gateway has connected and enabled
   New Game.
3. Tap **New Game**. The gateway saves the previous recorded moves,
   clears its pending moves and colour assignment, and sends the standard
   starting position to both sides. It keeps the host connections and
   connection settings.
4. After the gateway confirms the operation, the app disconnects and the
   Connect button returns to **red**. The app itself can stay open.
5. Start the next game. Colours may be reversed; their assignment is
   determined again by the first legal opening move.

**Connect alone never resets the game.** New Game is enabled only after
the gateway explicitly grants it. Repeating an unconfirmed request uses
the same request ID, so reconnecting does not automatically reset the game
again. The confirmation reports gateway processing and delivery to the
outputs, not a separate acknowledgement from either chess program.

The app is available only in boardless engine-vs-engine operation with the
software connected. A selected real board disables this control path.
Known boards detected during the app's scans take priority and prevent or
end the phone connection; they do not force a mid-game change of playing
board. Keep the app in the foreground during the short operation.
It does not receive moves, positions, engine evaluations or clocks.

EChessTool New Game sends **no hardware-reset command `T`**. The
BearChess/software-side `T` is not used as a New Game trigger in machine
mode. The separate **King/module cable-side `T` handling is preserved**.

For physical-board mode, rebuild the standard starting position for the
next game and prepare both chess programs accordingly. The gateway
recognizes the restored starting position; EChessTool is not needed for
that mode.

### PGN recording and session limits

**Engine-vs-engine games are recorded automatically as PGN**, with or
without an e-board. Only complete move positions enter the recording;
lifting a piece does not create a separate chess move. App-triggered
New Game also preserves short unfinished games when moves were recorded.
Repeated New Game operations before an opening move do not create empty
games. Checkmate uses the normal automatic saving path.

Saved-game retrieval is described [below](#retrieving-saved-games).
EChessTool currently provides New Game only; it does not download PGN.
On hardware where the gateway's BOOT button is accessible, holding it for
at least 1.5 seconds between moves saves/stops play and triggers USB export.
That is a separate stop/export action, not New Game, and is not required
for the app workflow. The finished enclosure/layout need not provide a
user-accessible button for New Game.

Power-off is not a save command. Save an unfinished game before switching
off. Pawn promotion remains limited: LED source/destination indications
alone do not identify the chosen promotion piece, so the gateway does not
guess one.

## Supported chess computer modules (cable side)

Tested working: MILLENNIUM King and Mephisto Phoenix. Both speak Mode B over
the cable, but not identically -- the gateway auto-detects a module's exact
checksum convention (plain 7-bit vs. odd-parity-encoded) from its first
frame and matches it in its own replies, so no build-time module selection
is needed here either.

## Automatic PGN recording

The gateway can automatically record every game played on the connected
e-board as a PGN file. Recording taps directly into the same board-status
stream every other part of the gateway already uses, so it works in every
supported configuration:

- Cable-connected chess computer (Phoenix/King) with any e-board
- [Engine vs. engine](#engine-vs-engine-with-or-without-an-e-board), with a virtual or physical board (matching current firmware)
- [Standalone mode](#standalone-mode-no-cable-computer-required) (ChessLink/Chessnut masquerade)
- Plain human-vs-human over-the-board play, with nothing else connected at all

### How it works

The gateway runs its own self-contained chess rules engine (legal move
generation, check/checkmate detection, standard SAN notation) purely from
the sequence of board positions it observes -- no external engine, app or
GUI is required for recording itself.

A game is saved automatically when:

- **Checkmate** is detected -- result recorded as `1-0` or `0-1`.
- The standard **starting position** is recognized again, meaning a new
  game has begun. The just-finished game is saved with result `*`, unless
  it was fewer than 10 full moves long, in which case it's discarded
  instead (almost always a setup/test, not a real game).

A manual result signal is also available mid-game: place both kings on one
of three square pairs (a deliberate gesture, not a legal move):

| Kings on | Result |
|---|---|
| d5 and e4 | White wins (`1-0`) |
| d4 and e5 | Black wins (`0-1`) |
| d4 and d5, or e4 and e5 | Draw (`1/2-1/2`) |

It doesn't matter which specific king sits on which square within a pair --
only that the two kings together occupy exactly that pair. Manually-signaled
and checkmate results are always saved regardless of game length.

The board itself also confirms the result for 3 seconds once the gesture is
recognized: LED boards (Millennium, Chessnut) light the same d4/d5/e4/e5
squares steady (not blinking); ManyaCynus shows `1:0`, `0:1`, or `1/2:1/2`
on its display.

The 20 most recently saved games are kept in a round-robin, oldest slot
overwritten first once all 20 are in use -- except a game is removed sooner,
right after [retrieval](#retrieving-saved-games) below has confirmed it was
copied off the gateway successfully.

### Retrieving saved games

Two independent ways to get saved games off the gateway:

**Chess PGN Master, over BLE.** Put the gateway into
[standalone Chessnut masquerade mode](#standalone-mode-no-cable-computer-required)
and connect from [Chess PGN Master](https://pgnmaster.kalab.com/) like you
would to a real Chessnut board -- its own download feature retrieves saved
games directly. With automatic protocol selection, a connected Millennium
board enables this Chessnut mode automatically. A connected Chessnut
Air/GO/Pro instead selects ChessLink mode, so use the USB retrieval method
below for games stored on the gateway in that configuration; the a4/b4
selection gesture no longer switches its protocol. Other supported board
types can still select Chessnut mode with the b4 gesture.

Getting this working required reading the real
[EasyLinkSDK](https://github.com/chessnutech/EasyLinkSDK) source: the app's
read thread only accepts raw board-status frames (the same format used for
live play), not pre-built PGN/FEN text, so the gateway replays each saved
game's recorded positions as if they were being played live. Once a
download completes, the gateway deletes that game from its own storage.

**USB, via a standalone Windows tool.** Trigger a **"queen gesture"**: set
up the standard starting position with one extra white queen placed on c4
(every one of these e-boards' piece sets includes a spare queen for
promotion anyway) -- the corner squares light up to confirm it was
recognized. Every saved game is then dumped over the gateway's native
USB-CDC connection to a PC, where a small standalone Windows tool saves each
one as its own `.pgn` file. Once the tool confirms every game saved
correctly, the gateway deletes exactly those games from its own storage --
a dump that never reaches the tool, or a partial transfer, leaves every game
in place for the next attempt. See [`pgntool/`](pgntool) for the tool itself
and full usage instructions.

This USB path was originally built as an independent fallback while the BLE
path above was still blocked on an undocumented SDK step -- both are now
confirmed working, so use whichever is more convenient.

## Web installer

Flash the gateway firmware directly from a supported browser (Chrome or
Edge), no toolchain install required:

**[https://parlue.github.io/eChessGw/](https://parlue.github.io/eChessGw/)**

Connect an ESP32-C3 SuperMini (or compatible board) via USB and follow the
on-page instructions. See [`docs/`](docs) for how the installer is built and
served.

## Project status

Both engine-vs-engine modes (with and without a physical board) are implemented.
The EChessTool Android app provides the tested boardless New Game workflow,
including colour changes between games; see [Engine vs. engine](#engine-vs-engine-with-or-without-an-e-board).
Firmware/APK publication is separate from this documentation update.

**Working**, against a genuine ChessLink board, a Chessnut board, a ManyaCynus
robot, and both a MILLENNIUM King and a Mephisto Phoenix chess computer
module. The gateway holds a full, continuous game exchange between the chess
computer module and whichever board it's connected to: the module reads and
writes its EEPROM registers over the cable exactly as it would with the
original wired peripheral, LED move suggestions are decoded and forwarded
correctly (including New Game/reset highlighting on boards that need it
translated), and moves -- including castling, en passant and promotion -- are
tracked and confirmed correctly in both directions for the length of a real
game. [Standalone mode](#standalone-mode-no-cable-computer-required)'s
ChessLink and Chessnut masquerades are both confirmed the same way against
real client software, including BearChess -- see that section for the full
client compatibility list.

## Version history

| Version | Adds |
|---|---|
| v1.0 | MILLENNIUM ChessLink board support (single-board) |
| v2.0 | + Chessnut Air/GO/Pro support (multi-board) |
| v3.0 | + Mephisto Phoenix chess computer support (cable-side checksum auto-detect) |
| v4.0 | + ManyaCynus robot support (castling, en passant, promotion) |
| v5.0 | + [Standalone mode](#standalone-mode-no-cable-computer-required): BLE-to-BLE ChessLink/Chessnut masquerade, no cable chess computer required |
| v5.1 | Fix: Chessnut+Mephisto Phoenix status checksum (single-square changes and captures could silently fail to register); standalone mode now recovers automatically if a cable module boots slowly instead of needing a power cycle |
| v5.2 | Fix: BearChess's ChessLink move-suggestion LEDs (a ghost-square filter built for Mephisto Phoenix's own reset splash was wrongly eating small real move suggestions from BearChess) |
| v6.0 | + [Automatic PGN game recording](#automatic-pgn-recording) with USB retrieval (queen-gesture trigger, standalone Windows tool, delete-on-confirmed-transfer) |
| v6.1 | Fix: the manual king-gesture result signal could be lost entirely if its target squares (d4/d5/e4/e5) were occupied by other pieces or the two kings didn't arrive together -- those in-progress states now get unlimited patience instead of counting against (and potentially triggering) the desync-recovery timeout |
| v6.2 | Chess PGN Master's BLE game download now actually works (sends raw board-status frames instead of pre-built text, matching what the real EasyLinkSDK's read thread expects) and properly deletes each game from the gateway after a successful pickup; + initial (real-hardware-untested) iChessOne board driver |
| v6.3 | Manual king-gesture game results are now also confirmed on the board itself (3s LED/display signal); + ManyaCynus manual position override to recover from an unexpected mid-game BLE reconnect without losing the game |
| v6.4 | ManyaCynus: on firmware 1.4.2+, the gateway now auto-detects the version and disables Cynus's own onboard illegal-move checking, which previously could interfere with an external chess computer driving the game |
| v6.5 | Fix: the standalone-mode masquerade gesture (second white queen on a4/b4) never worked on ManyaCynus -- the gateway's own single-legal-move check rejected the extra queen before the masquerade selection logic ever saw it; confirmation signal text changed to "ChessL"/"Chnut", shown for 3s (was "CSLMode"/"NutMode", 2s) |
| v6.6 | Fix: a connected Chessnut app's move commands were silently ignored on ManyaCynus during live play (Chess Dojo confirmed affected) -- now decoded and sent to the robot arm |
| v6.7 | Fix: the same Chessnut highlight command is also used by a connected app to echo a move it just saw the human make by hand -- confirmed on real hardware to make ManyaCynus's robot arm re-grab and disturb a piece the human had already placed correctly (a king, right after a hand-played castling). Now recognized and ignored (it's textually identical to the human move the gateway itself just detected) instead of re-executed, so the robot only ever moves for the computer's own side; also inactive while Free Analysis or Set Position is active. Separately: two BLE masquerade services (ChessLink and Chessnut) were both always connectable regardless of which one was actually selected, which could route a client to the wrong one and explain total silence -- the non-selected one now rejects connections outright instead |
| v6.8 | Fix: in standalone BLE ChessLink masquerade mode, the board-status frame sent to a connected app (e.g. BearChess) was relayed in the cable module's own wire orientation (rotated 180 degrees) instead of plain board order, so the app never received a correct position; also adds a 1s connection health-check watchdog that restarts advertising if it goes stale |
| v6.9 | Renamed the project to eChessGw (was BluetoothMax) and switched all documentation/UI text from "Bluetooth" to "BLE" to avoid any Bluetooth SIG trademark conflict -- no functional change to the protocol or hardware support. Also removed an unjustified BLE MTU request (128, never actually required by any supported client) |
| v9.3 | ManyaCynus: pure software-driven game replay over the ChessLink BLE masquerade (e.g. Chess PGN Master stepping through a loaded game, with no human ever scanning a move) now works end-to-end. Fixed 3 related issues, each scoped so the King/Phoenix cable path and BearChess are provably unaffected: (1) BLE app clients (Chess Dojo, Chess PGN Master) encode the LED move-highlight grid 180 degrees rotated relative to real King/Phoenix cable hardware, despite the identical wire format -- confirmed via a real Chess Dojo game (outgoing status reached it correctly oriented, but its own move highlights decoded mirrored, e.g. e2-e4 arriving as d7-d5); corrected only at the BLE entry point, never inside the shared decoder; (2) the LED-channel move decoder now tracks the actually-alternating side to move instead of a single game-long fixed color whenever no human has scanned a move yet this game, matching the fix already used for Chessnut replay -- both colors arriving over the same channel used to get silently dropped or rejected every other move; (3) removed the automatic "the scan looks flipped, so flip must be on" heuristic entirely (it assumed a move arriving over the LED channel before any scan always meant the software plays White, which stopped holding once software could drive both colors) -- board orientation now comes only from the manual black-King gesture, moved to b5/b6 (see the option table above) |
| v10 | + Engine-vs-engine `machine_gateway` subsystem: two chess computers/apps can play each other through the gateway, with or without a physical board (see [Engine vs. engine](#engine-vs-engine-with-or-without-an-e-board)) |
| v11 | + **Certabo** board support (Bluetooth LE / Nordic UART): the board's 34 piece chips are read in at every start ([see above](#certabo--spectrum-selecting-the-board-and-learning-pieces)), mono LEDs show suggestions from a MILLENNIUM King, Mephisto Phoenix and wireless clients; the human's own move is shown on the Certabo with a King. Also: LED highlights sent by BLE clients (BearChess, Chess Dojo) are now used exactly as received -- the 180 degree rotation added in v9.3 mirrored them on Certabo and Chessnut boards, and client frames are handled like a King's single-shot suggestions (double pawn pushes and castling highlight the right squares); `ChessnutMove` robotic board support is included |
| v12 (current) | **Tabutronic Spectrum integrated and tester-confirmed.** Certabo uses extra queens on d3/d6; Spectrum uses e3/e6. Early setup assistance, 34-piece learning, centre confirmation flashes and removal of extra queens. Spectrum defaults to blue 80%, with colour/brightness gestures. Independent frozen V12 build; normal SuperMini development remains separate. |

## Components

- ESP32-C3 SuperMini
- HW-027 RS-232-to-TTL module with MAX3232
- 9 V to 3.2 V DC/DC step-down converter (Pololu D36V6F3)
- 4-pin Mini-DIN plug or suitable connection cable
- Wires and suitable plug or solder connections
- Optional enclosure, strain relief and insulation material

## Electrical interfaces

### ChessLink cable side

Confirmed-correct pin assignment for the 4-pin Mini-DIN connector, viewed
face-on into the socket, keyway/notch at the bottom, guide pin at the top:

| Clock position | Wire color | Function |
|---:|---|---|
| 1 o'clock | Yellow | +9 V supply (from the chess computer module) |
| 5 o'clock | Black | RS-232 IN (into the level-shifter's input) |
| 7 o'clock | Green | GND |
| 11 o'clock | Red | RS-232 OUT (from the level-shifter's output) |

If you're building your own cable, trust this table over any datasheet-style
"pin 1/2/3/4" numbering, and verify against a multimeter/oscilloscope before
trusting a new build.

### Serial settings

- 38400 baud
- 7 data bits
- Odd parity
- 1 stop bit (`7O1`)

The firmware sends this as plain 8N1 with the odd-parity bit computed in
software and packed into the 8th data bit -- this produces the identical
10-bit wire waveform as native 7O1 framing while sidestepping inconsistent
7O1 support in common USB-UART hardware. This matches how other independent
ChessLink implementations handle the same spec text.

## Wiring diagram

### Power

```text
Module +9 V     ──> DC/DC IN+
Module GND      ──> DC/DC IN-

DC/DC OUT 3.2 V ──> ESP32-C3 3V3
DC/DC GND       ──> ESP32-C3 GND

ESP32-C3 3V3    ──> HW-027 VCC (+), TTL side
ESP32-C3 GND    ──> HW-027 GND (-), TTL side
```

All components must share a common ground. The 9 V cable supply must never be
connected directly to an ESP32 GPIO or to the ESP32 3.3 V pin.

### Data lines

```text
Module TX (RS-232 OUT, see pinout table)
    ──> HW-027 RS-232 input
    ──> HW-027 TTL output
    ──> ESP32-C3 GPIO20 (RX)

ESP32-C3 GPIO21 (TX)
    ──> HW-027 TTL input
    ──> HW-027 RS-232 output
    ──> Module RX (RS-232 IN, see pinout table)
```

GPIO20 is used exclusively as the receive path from the chess computer
module. GPIO21 is the transmit path to the module.

## Important safety notes

- Connect the ESP32 only to the **TTL side** of the HW-027.
- Verify supply voltages and ground with a multimeter before connecting the
  hardware.
- Power the TTL side of the HW-027 with 3.3 V.
- Never connect RS-232 levels directly to an ESP32 GPIO.
- Check the viewing direction of Mini-DIN connectors: the solder side and plug
  side are mirrored, and the pinout table above is specified face-on into the
  socket -- double-check orientation before trusting a measurement.
- Disconnect power before changing any wiring.

## Firmware

Actively-developed PlatformIO environment in this repository:

```ini
[env:esp32-c3-supermini]
```

The firmware operates as a bidirectional gateway between the chess
computer's serial Mode B interface and whichever board's own BLE protocol it
connects to: on the cable side it always speaks Mode B (framing, odd parity,
checksums, LED encoding, register reads/writes) exactly as a genuine
peripheral would; on the BLE side, a real ChessLink board is relayed as-is,
while a Chessnut board's own binary protocol -- or ManyaCynus's own line-based
robot-control protocol -- is translated to and from the same Mode B
representation the cable side already understands. The rest of the gateway
(status caching, resend-on-change, LED-clear timing) is shared and doesn't
need to know which board produced the data.

[Standalone mode](#standalone-mode-no-cable-computer-required)'s two BLE
masquerade roles are self-contained modules (`chesslink_server.*`,
`chessnut_server.*`) that answer every host command themselves using the
same status cache, rather than relaying a real Mode B/Chessnut peer.

For a ready-to-flash build, see [Web installer](#web-installer) above.

## Contact

Board manufacturers who would like their board supported, and anyone who'd
like a ready-built device but can't solder one themselves, are welcome to
get in touch: dsommerfeld@mac.com

**Support:** also available on Discord -- server **electricchess**.

## License

Licensed under the [PolyForm Noncommercial License 1.0.0](LICENSE). Any
noncommercial use -- building it for yourself, hobby projects, research -- is
permitted; commercial use and distribution are reserved to the copyright
holder.

## Trademark, copyright and protocol notice

eChessGw is an independent, unofficial interoperability project. It is not
affiliated with, endorsed by or sponsored by MILLENNIUM 2000 GmbH, Phoenix
Chess Systems, or any other vendor named in this document.

MILLENNIUM, ChessLink, Chessnut, ManyaCynus, Mephisto Phoenix and related
product names, trademarks, documentation and protocol specifications remain
the property of their respective rights holders -- Mephisto Phoenix is a
product of Phoenix Chess Systems (Netherlands, phoenixcs.nl), developed in
cooperation with MILLENNIUM 2000. This project does not claim ownership of
any of these protocols and does not distribute original firmware, software
or other copyrighted material from any vendor.

The *Bluetooth®* word mark and logos are registered trademarks owned by
Bluetooth SIG, Inc., and any use of such marks by this project is under
license. This project uses "BLE" (Bluetooth Low Energy) descriptively to
refer to the underlying radio technology only, and is not affiliated with,
endorsed by or sponsored by Bluetooth SIG, Inc.
