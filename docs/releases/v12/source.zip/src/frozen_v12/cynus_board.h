#pragma once

// Driver for the Cynus robot's own BLE protocol (service 0xFFF0 / char
// 0xFFF1, line-based text commands). This is a port of the user's own
// proven CynusLink project (C:\Users\DirkSommerfeld\Documents\CynusLink_Test),
// which bridges the exact same Cynus robot to a real chess computer over its
// OWN BLE "MILLENNIUM CHESS" server role and is confirmed to hold full games
// with King. Here the chess computer (King/Phoenix) is instead on our
// project's cable side, so only CynusLink's chess/game logic is ported --
// its own BLE-server transport (sendCL) is replaced by this project's
// existing cable pipeline (onBoardStatusFrame()/writeFrameToKing() in
// main.cpp), which already handles acks, checksums and framing generically
// for every board driver.

#include <string>

#include "board_driver.h"

extern const char kCynusBoardName[];  // matched as a "CYNUS-" prefix

bool cynusConnect(const NimBLEAddress& address);
bool cynusIsConnected();
void cynusPoll();

// Call on every King/Phoenix 'L' frame with the raw, already parity-stripped
// and checksum-validated 167-byte Mode-B frame ('L' + 2 hex slot digits + 81
// LED bytes as hex pairs + 2 hex checksum digits). Parses the LED corner
// grid itself and, once a candidate move has been stable for
// kLedMoveStableMs (ported from CynusLink's LED_MOVE_STABLE_MS), commits it
// by sending "move <uci>" to Cynus's robot arm.
void cynusHandleLedFrame(const uint8_t frame167[167]);

// Cynus has no LEDs of its own to clear; present only so main.cpp's
// clearActiveBoardLeds() dispatch stays uniform across board types.
void cynusClearLeds();

// Shows short (<=7 char) feedback text on Cynus's own display -- exposed so
// main.cpp can show BT-BT mode-selection signals ("OK", "ChessL", ...) on
// boards that have no LEDs of their own.
void cynusShowText(const char* text);

// A connected Chessnut-protocol client's "light these squares" command has
// no LEDs to relay to on Cynus -- forwarded here instead so it can command
// ManyaCynus's own robot arm to execute the move, for normal human-vs-
// computer play. See the .cpp's own comment for the echo-protection this
// relies on (only ever executes a genuine new engine move, never a replay
// of the human's own just-made move).
void cynusExecuteHighlightedMove(const SquareHighlight* highlights, size_t count);

// Sends a position directly to Cynus via its "setup: <FEN>\n" command (new
// firmware capability) -- the robot arm builds the position itself, so a
// puzzle/endgame position can be set up without a human physically doing it
// and scanning it in. fenPlacement is just the placement field (e.g.
// "8/P4K2/2PpnP2/2p5/2N5/p6k/8/8"). Returns false immediately if the string
// isn't a valid 64-square placement or an experimental mode is active;
// Cynus's own asynchronous "illegal FEN" reply is the second rejection path.
bool cynusSetupPosition(const std::string& fenPlacement);

#ifdef CHESSLINK_ENABLE_MACHINE
// Cancel a not-yet-executed LED candidate on an explicit machine New Game.
// Does not interrupt a robot movement already sent to the hardware.
void cynusCancelPendingMachineMove();
#endif
