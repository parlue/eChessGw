#include "../include/cable_status_policy.h"
#include <cassert>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include "../.pio/cable_status_actual.inc"

int main() {
  // Captured King New Game idle L: 0F + 162 zero digits, checksum 3A.
  // Verify the real validator AND the main.cpp classification, not just
  // precomputed booleans. The Phoenix fixture is its observed L01...CD.
  uint8_t kingFrame[167];
  memset(kingFrame, '0', sizeof(kingFrame));
  kingFrame[0] = 'L'; kingFrame[2] = 'F';
  kingFrame[165] = '3'; kingFrame[166] = 'A';
  uint8_t sum[2];
  computeModeBChecksumHex(sum, kingFrame, 165, true);
  assert(sum[0] == 'B' && sum[1] == 'A');
  CableStatusPolicy measuredKing;
  classify(measuredKing, kingFrame, sizeof(kingFrame));
  assert(measuredKing.allowActiveGoStatus());

  uint8_t phoenixFrame[167];
  memcpy(phoenixFrame, kingFrame, sizeof(phoenixFrame));
  phoenixFrame[2] = '1'; phoenixFrame[165] = 'C'; phoenixFrame[166] = 'D';
  CableStatusPolicy measuredPhoenix;
  classify(measuredPhoenix, phoenixFrame, sizeof(phoenixFrame));
  assert(measuredPhoenix.convention() == CableStatusPolicy::Convention::Encoded);
  assert(!measuredPhoenix.allowActiveGoStatus());
  classify(measuredKing, phoenixFrame, sizeof(phoenixFrame));
  assert(!measuredKing.allowActiveGoStatus());

  CableStatusPolicy setup;
  const uint8_t statusRequest[] = {'S', '5', '3'};
  classify(setup, statusRequest, sizeof(statusRequest));
  assert(!setup.allowActiveGoStatus()); // short plain setup is not evidence
  kingFrame[166] = '0'; // corrupt New Game must not enable active reports
  classify(setup, kingFrame, sizeof(kingFrame));
  assert(!setup.allowActiveGoStatus());

  CableStatusPolicy king;
  assert(!king.allowActiveGoStatus());
  king.observe(true, true); // same checksum under both conventions
  assert(!king.allowActiveGoStatus());
  king.observe(false, false); // invalid data cannot select a convention
  assert(!king.allowActiveGoStatus());
  king.observe(true, false);
  assert(king.allowActiveGoStatus());
  king.observe(true, true);
  assert(king.allowActiveGoStatus());

  CableStatusPolicy phoenix;
  for (int i = 0; i < 20; ++i) phoenix.observe(true, true);
  assert(!phoenix.allowActiveGoStatus());
  phoenix.observe(false, true);
  assert(!phoenix.allowActiveGoStatus());
  phoenix.observe(true, false); // encoded evidence must remain sticky
  assert(!phoenix.allowActiveGoStatus());
  phoenix.observe(true, true);
  assert(!phoenix.allowActiveGoStatus());

  king.observe(false, true); // stronger protection overrides earlier plain
  assert(!king.allowActiveGoStatus());
  king = CableStatusPolicy{}; // reboot starts conservatively again
  assert(!king.allowActiveGoStatus());
  puts("PASS: captured King/Phoenix frames, real validator/classifier, setup, corruption, ambiguity, sticky protection, reset");
}
