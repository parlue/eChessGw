// Test doubles for the actual scan/connect/commit functions extracted from
// main.cpp by tools/test_reconnect.py. No radio or firmware upload required.
#include <algorithm>
#include <atomic>
#include <cassert>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

enum class BoardType { Unknown, Millennium, Chessnut, Cynus, IChessOne };
struct NimBLEUUID { explicit NimBLEUUID(const char*) {} };
struct NimBLEAddress {
  std::string value;
  int type = 0;
  std::string toString() const { return value; }
  int getType() const { return type; }
  bool operator!=(const NimBLEAddress& rhs) const {
    return value != rhs.value || type != rhs.type;
  }
};
struct NimBLEAdvertisedDevice {
  std::string name;
  NimBLEAddress address;
  bool chesslinkService = false;
  bool isAdvertisingService(const NimBLEUUID&) const { return chesslinkService; }
  bool haveName() const { return !name.empty(); }
  std::string getName() const { return name; }
  NimBLEAddress getAddress() const { return address; }
};
struct NimBLEScanResults {
  std::vector<NimBLEAdvertisedDevice> devices;
  int getCount() const { return static_cast<int>(devices.size()); }
  const NimBLEAdvertisedDevice* getDevice(int i) const { return &devices[i]; }
};
struct NimBLEScan {
  NimBLEScanResults results;
  void setActiveScan(bool) {}
  NimBLEScanResults getResults(int, bool) { return results; }
  void clearResults() {}
} scanner;
struct NimBLEDevice { static NimBLEScan* getScan() { return &scanner; } };
struct Logger {
  void println(const char*) {}
  template<class... T> void printf(const char*, T...) {}
} Serial;
struct KnownBoard { const char* name; BoardType type; };
const KnownBoard kKnownBoards[] = {
  {"chessnut", BoardType::Chessnut}, {"MILLENNIUM CHESS", BoardType::Millennium}
};
enum class LedState { Searching, Connected };
LedState ledState = LedState::Searching;
constexpr size_t kModeBStatusFrameLength = 67;
constexpr uint32_t kFallbackAutoReportIntervalMs = 41;
uint32_t millis() { return 12345; }
BoardType activeBoardType = BoardType::Unknown;
BoardType sessionBoardType = BoardType::Unknown;
NimBLEAddress sessionBoardAddress;
std::atomic<bool> connectInProgress{false}, connectFinished{false};
bool connectSucceeded = false, compareReconnectedPosition = false;
uint8_t preReconnectStatus[67] = {}, cachedBoardStatus[67] = {};
bool haveCachedBoardStatus = false, haveSentStatusToKing = false;
bool haveLoggedStatus = false, ledsAwaitingClear = false;
uint32_t lastCableStatusSendMs = 0, autonomousStatusIntervalMs = 41;
bool driverSuccess = false;
int driverCalls = 0;
bool connectDriver(const NimBLEAddress&) { ++driverCalls; return driverSuccess; }
bool millenniumConnect(const NimBLEAddress& a) { return connectDriver(a); }
bool chessnutConnect(const NimBLEAddress& a) { return connectDriver(a); }
bool cynusConnect(const NimBLEAddress& a) { return connectDriver(a); }
bool ichessoneConnect(const NimBLEAddress& a) { return connectDriver(a); }

#include "reconnect_actual.inc"

int main() {
  const NimBLEAddress go{"11:22:33:44:55:66", 0};
  const NimBLEAddress otherGo{"11:22:33:44:55:77", 0};
  scanner.results.devices = {{"Chessnut GO", go}};
  assert(!connectToBoard());
  assert(sessionBoardType == BoardType::Unknown); // failure never locks

  driverSuccess = true;
  connectInProgress = true;
  connectSucceeded = connectToBoard();
  assert(connectSucceeded && sessionBoardType == BoardType::Chessnut);
  assert(!(sessionBoardAddress != go));
  assert(activeBoardType == BoardType::Unknown); // worker cannot expose driver
  connectFinished = true;
  finishConnectAttempt();
  assert(!connectInProgress && activeBoardType == BoardType::Chessnut);

  scanner.results.devices = {
      {"MILLENNIUM CHESS", {"22:22:33:44:55:66", 0}}};
  const int calls = driverCalls;
  assert(!connectToBoard());
  assert(driverCalls == calls); // another protocol remains excluded
  assert(!(sessionBoardAddress != go));

  scanner.results.devices.push_back({"Chessnut GO", otherGo});
  assert(connectToBoard());
  assert(!(sessionBoardAddress != otherGo));
  scanner.results.devices = {{"Chessnut GO", {go.value, 1}}};
  assert(connectToBoard()); // changed address type is allowed too
  assert(sessionBoardAddress.getType() == 1);
  scanner.results.devices = {{"Chessnut GO", go}};
  assert(connectToBoard());

  // The pinned board may advertise without a name, behind other boards.
  scanner.results.devices = {{"", go}};
  memset(cachedBoardStatus, '.', sizeof(cachedBoardStatus));
  cachedBoardStatus[1] = 'K';
  haveCachedBoardStatus = true;
  connectInProgress = true;
  connectSucceeded = connectToBoard();
  assert(connectSucceeded && haveCachedBoardStatus);
  connectFinished = true;
  finishConnectAttempt();
  assert(!haveCachedBoardStatus && compareReconnectedPosition);
  assert(preReconnectStatus[1] == 'K');
  assert(!connectInProgress);

  // Failed attempts and a second drop before a new status preserve the
  // last comparison baseline and the selected protocol.
  driverSuccess = false;
  connectInProgress = true;
  connectSucceeded = connectToBoard();
  connectFinished = true;
  finishConnectAttempt();
  assert(!connectInProgress && preReconnectStatus[1] == 'K');
  assert(compareReconnectedPosition && !(sessionBoardAddress != go));
  driverSuccess = true;
  connectInProgress = true;
  connectSucceeded = connectToBoard();
  connectFinished = true;
  finishConnectAttempt();
  assert(preReconnectStatus[1] == 'K' && compareReconnectedPosition);

  // Reboot creates an unlocked session again.
  sessionBoardType = BoardType::Unknown;
  scanner.results.devices = {{"MILLENNIUM CHESS", otherGo}};
  assert(connectToBoard() && sessionBoardType == BoardType::Millennium);
  scanner.results.devices = {{"VirtualT2", go, true}};
  assert(connectToBoard()); // ChessLink service, different name and address
  assert(!(sessionBoardAddress != go));
  driverSuccess = false;
  scanner.results.devices = {{"Impostor", otherGo, true}};
  assert(!connectToBoard()); // advertisement alone is not a successful setup
  assert(!(sessionBoardAddress != go));
  puts("Reconnect session tests passed");
}
