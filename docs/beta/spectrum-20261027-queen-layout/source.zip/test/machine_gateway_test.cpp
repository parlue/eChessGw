#include <cassert>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <array>
#include <vector>
#include <thread>
#include <utility>
#define CHESSLINK_ENABLE_MACHINE 1
#include "../include/machine/selection.h"
#include "../include/machine/castle_motion.h"
#include "../include/machine/delivery_gate.h"
#include "../include/machine/pending_leds.h"
#include "../include/machine/players.h"
#include "../include/cable_status_policy.h"
#include "../.pio/machine_gateway_rules.inc"
#include "../.pio/machine_gateway_protocol.inc"

uint32_t fakeNow = 1000;
uint32_t millis() { return fakeNow; }
void delay(unsigned) {}
constexpr int LOW = 0, INPUT_PULLUP = 2;
void pinMode(int, int) {}
int digitalRead(int) { return 1; }
struct Log { template<class... T> void printf(const char*, T...) {} void println(const char*) {} } Serial;
int __builtin_popcountll(uint64_t n) { int c = 0; while (n) { n &= n - 1; ++c; } return c; }
bool subscribed = true;
unsigned offers = 0, stopped = 0, stoppedScans = 0;
void machineGatewayStopBoardSearch() { ++stoppedScans; }
void machineGatewayCancelBoardCommand() {}
void clearBoardLeds(BoardType) {}
using Frame = std::array<uint8_t, 67>;
std::vector<Frame> notifications, cableStatuses, completePositions;
Frame sentStatus{};
void chesslinkServerStart() { ++offers; }
void chesslinkServerStopMachineOffer() { ++stopped; }
bool chesslinkServerMachineSubscribed() { return subscribed; }
bool chesslinkServerMachineStatusSent(const uint8_t* f) { return subscribed && memcmp(f, sentStatus.data(), 67) == 0; }
void chesslinkServerPublishStatus(const uint8_t* f) {
  if (subscribed) { memcpy(sentStatus.data(), f, 67); notifications.push_back(sentStatus); }
}
void pgnRecorderOnBoardStatus(const uint8_t* f) { Frame v; memcpy(v.data(), f, 67); completePositions.push_back(v); }
void machineSaveAndExport() {}
unsigned recorderRestarts = 0;
void machineRecorderRestart() { ++recorderRestarts; }
void machineGatewayResetGame();
size_t machineGatewayWriteCable(const uint8_t* f, size_t n) {
  if (n == 67 && f[0] == 's') { Frame v; memcpy(v.data(), f, n); cableStatuses.push_back(v); }
  return n;
}
#include "../.pio/machine_gateway_runtime.inc"
unsigned physicalLedCalls = 0;
uint8_t physicalLedFrame[167] = {};
BoardType testBoardType = BoardType::Chessnut;
BoardType currentBoardType() { return testBoardType; }
void dispatchLedFrameToBoard(BoardType, const uint8_t* f) {
  ++physicalLedCalls; memcpy(physicalLedFrame, f, 167);
}
size_t writeFrame(const uint8_t*, size_t n) { return n; }
#include "../.pio/machine_gateway_ble_route.inc"
#include "../.pio/machine_gateway_ble_reset.inc"

int sq(const char* s) { return (s[1] - '1') * 8 + s[0] - 'a'; }
char piece(const Frame& f, int s) { return char(f[1 + modeBStatusWireIndex(s % 8, s / 8 + 1)]); }
void cableIdle() {
  uint8_t f[167]; encodeLedFrame(nullptr, 0, f, false);
  machineGatewayCommand(f, 167);
}
void pump(unsigned ms) {
  for (unsigned i = 0; i < ms; i += 100) {
    fakeNow += 100;
    cableIdle();
    machineGatewayPoll();
  }
}
void boot() {
  machineGatewayCableActivity();
  assert(offers == 1 && notifications.empty());
  assert(machineGatewayAcceptSoftware());
  machineGatewayServiceSelection();
  assert(machineGatewayActive() && completePositions.size() == 1);
  assert(machineGatewayWantsBoard());
  pump(1500);
}
void suggest(bool software, const char* from, const char* to) {
  uint8_t f[167]; const uint8_t squares[] = {uint8_t(sq(from)), uint8_t(sq(to))};
  encodeLedFrame(squares, 2, f, false);
  if (software) serverLed(f, 167); else machineGatewayCommand(f, 167);
}
void move(bool software, const char* from, const char* to, unsigned stages = 2) {
  const size_t begin = notifications.size(), pgnBegin = completePositions.size();
  const char moving = virtualGame.board[sq(from)];
  suggest(software, from, to);
  pump(6500);
  assert(!halted && !lifting);
  assert(notifications.size() == begin + stages);
  assert(completePositions.size() == pgnBegin + 1); // No lift recorded as a move.
  assert(piece(notifications[begin], sq(from)) == '.');
  assert(piece(notifications.back(), sq(to)) == moving);
  assert(virtualGame.board[sq(from)] == '.' && virtualGame.board[sq(to)] == moving);
  assert(cableStatuses.back() == notifications.back());
  assert(physicalLedCalls == 0);
}
void boardReport(const char board[64]) {
  uint8_t frame[67] = {'s'};
  for (int i = 0; i < 64; ++i) frame[1 + modeBStatusWireIndex(i % 8, i / 8 + 1)] = board[i];
  computeModeBChecksumHex(frame + 65, frame, 65, false);
  machineGatewayBoardStatus(frame);
}
void attachBoard() {
  assert(machineGatewaySelectPhysical());
  machineGatewayBoardLink(true);
  boardReport(kStartBoard);
  assert(boardSynchronized);
  pump(1500);
}
void physicalMove(bool software, const char* from, const char* to) {
  const size_t n = notifications.size();
  suggest(software, from, to); pump(400);
  assert(lifting && notifications.size() == n); // No synthetic lift.
  char actual[64], target[64]; machineBoard(actual);
  assert(machinePreview(sq(from), sq(to), target));
  actual[sq(from)] = '.'; boardReport(actual);
  assert(lifting && notifications.size() == n + 1);
  pump(2000); assert(lifting); // Time alone never completes the move.
  boardReport(target); assert(!lifting && !halted);
  assert(memcmp(virtualGame.board, target, 64) == 0);
  pump(1500);
}
void robotMove(bool software, const char* from, const char* to, size_t stages = 2) {
  const size_t n = notifications.size();
  suggest(software, from, to); pump(4000);
  assert(lifting && notifications.size() == n);
  char target[64]; assert(machinePreview(sq(from), sq(to), target));
  boardReport(target); assert(robotConfirmedReplay);
  pump(6500); assert(!lifting && notifications.size() == n + stages);
  assert(memcmp(virtualGame.board, target, 64) == 0);
}
void selectionTests() {
  MachineSelection standalone;
  assert(standalone.physicalConnected());
  assert(standalone.softwareConnected() && !standalone.machine());
  for (int i = 0; i < 200; ++i) {
    MachineSelection race; assert(race.cableActivity());
    bool board = false, software = false;
    std::thread a([&] { board = race.physicalConnected(); });
    std::thread b([&] { software = race.softwareConnected(); });
    a.join(); b.join();
    assert(board);
    assert(!software || race.board());
    assert(!race.cableActivity());
    assert(race.physicalConnected() && race.softwareConnected() == software);
    MachineSelection cutoff; cutoff.cableActivity(); assert(cutoff.softwareConnected());
    bool accepted = false, locked = false;
    std::thread c([&] { accepted = cutoff.physicalConnected(); });
    std::thread d([&] { locked = cutoff.lockVirtual(); });
    c.join(); d.join(); assert(accepted != locked);
    assert(cutoff.physicalConnected() == accepted);
  }
}
int main(int argc, char** argv) {
  assert(argc == 2);
  const char* scenario = argv[1];
  if (!strcmp(scenario, "selection")) { selectionTests(); }
  else if (!strcmp(scenario, "standalone")) {
    assert(machineGatewaySelectPhysical());
    assert(machineGatewayAcceptSoftware());
    uint8_t f[167]; for (int i = 0; i < 167; ++i) f[i] = uint8_t(i);
    f[0] = 'L'; serverLed(f, 167);
    assert(physicalLedCalls == 1 && !machineGatewayActive());
    for (int i = 0; i < 81; ++i) for (int j = 0; j < 2; ++j)
      assert(physicalLedFrame[3 + i * 2 + j] == f[3 + (80 - i) * 2 + j]);
    assert(physicalLedFrame[1] == f[1] && physicalLedFrame[166] == f[166]);
    assert(offers == 0 && notifications.empty());
  }
  else if (!strcmp(scenario, "physical")) {
    machineGatewayCableActivity(); assert(offers == 1);
    assert(machineGatewaySelectPhysical());
    machineGatewayServiceSelection(); assert(stopped == 1);
    assert(!machineGatewayAcceptSoftware());
    machineGatewayCableActivity(); machineGatewayPoll();
    assert(offers == 1 && notifications.empty() && cableStatuses.empty() && completePositions.empty());
    assert(machineGatewaySelectPhysical()); // Reconnect does not open machine mode.
  } else {
    boot();
    if (!strcmp(scenario, "board_setup")) {
      assert(machineGatewaySelectPhysical()); machineGatewayBoardLink(true);
      char wrong[64]; memcpy(wrong, kStartBoard, 64); wrong[sq("a2")] = '.';
      boardReport(wrong); assert(!boardSynchronized);
      suggest(false, "d2", "d4"); pump(3000);
      assert(!lifting && candidateFrom == sq("d2"));
      boardReport(kStartBoard); pump(400); assert(lifting);
      char target[64]; machinePreview(sq("d2"), sq("d4"), target);
      boardReport(target); assert(!lifting);
    }
    if (!strcmp(scenario, "robot_castle")) {
      testBoardType = BoardType::Cynus; attachBoard();
      robotMove(true, "e2", "e4"); robotMove(false, "e7", "e5");
      robotMove(true, "g1", "f3"); robotMove(false, "b8", "c6");
      robotMove(true, "f1", "c4"); robotMove(false, "g8", "f6");
      robotMove(true, "e1", "g1", 4);
      robotMove(false, "f8", "e7"); robotMove(true, "d2", "d3");
      robotMove(false, "e8", "g8", 4);
    }
    if (!strcmp(scenario, "robot")) {
      testBoardType = BoardType::Cynus; attachBoard();
      suggest(false, "d2", "d4"); const size_t n = notifications.size();
      pump(5000); assert(lifting && notifications.size() == n);
      // Actual Cynus grid convention: file ascending, rank 8 first.
      // d2/d4 must illuminate file corners 3/4 and rank corners 6/7,4/5.
      for (int file = 0; file < 9; ++file) for (int rank = 0; rank < 9; ++rank) {
        const bool lit = (file == 3 || file == 4) && rank >= 4 && rank <= 7;
        const int offset = 3 + 2 * (file * 9 + rank);
        assert(physicalLedFrame[offset] == (lit ? 'F' : '0'));
        assert(physicalLedFrame[offset + 1] == (lit ? 'F' : '0'));
      }
      char target[64]; assert(machinePreview(sq("d2"), sq("d4"), target));
      boardReport(target); assert(lifting && robotConfirmedReplay);
      assert(virtualGame.board[sq("d2")] == 'P');
      pump(4000); assert(!lifting && !robotConfirmedReplay && virtualGame.board[sq("d4")] == 'P');
      assert(notifications.size() == n + 2);
      // Phoenix stops polling while the robot executes BearChess's reply.
      timing.observe(false, true);
      suggest(true, "g8", "f6"); pump(4000);
      assert(lifting && !robotConfirmedReplay);
      assert(machinePreview(sq("g8"), sq("f6"), target));
      const size_t cableBegin = cableStatuses.size();
      for (int i = 0; i < 20; ++i) { fakeNow += 100; machineGatewayPoll(); }
      assert(cableStatuses.size() == cableBegin); // No invented robot completion.
      boardReport(target);
      for (int i = 0; i < 40; ++i) { fakeNow += 100; machineGatewayPoll(); }
      assert(!lifting && !robotConfirmedReplay);
      assert(cableStatuses.size() == cableBegin + 6); // Three sends per stage.
      assert(piece(cableStatuses[cableBegin], sq("g8")) == '.');
      assert(piece(cableStatuses[cableBegin], sq("f6")) == '.');
      assert(piece(cableStatuses.back(), sq("f6")) == 'n');
      assert(cableStatuses.back() == notifications.back());
    }
    if (!strcmp(scenario, "board")) {
      attachBoard();
      physicalMove(false, "d2", "d4"); physicalMove(true, "g8", "f6");
      boardReport(kStartBoard);
      assert(!players.assigned() && !awaitingStart && boardSynchronized);
      assert(recorderRestarts == 1 && machineWhiteToMove());
      pump(1500); physicalMove(true, "e2", "e4");
      machineGatewayResetGame(); assert(awaitingStart);
      suggest(false, "d2", "d4"); pump(2000); assert(!lifting);
      boardReport(kStartBoard); assert(!awaitingStart);
      pump(1500); physicalMove(false, "e2", "e4");
      assert(stoppedScans == 0);
    }
    if (!strcmp(scenario, "board_disconnect")) {
      attachBoard(); suggest(false, "d2", "d4"); pump(400); assert(lifting);
      machineGatewayBoardLink(false); const size_t n = notifications.size();
      pump(8000); assert(lifting && notifications.size() == n && machineGatewayWantsBoard());
      assert(machineGatewaySelectPhysical()); machineGatewayBoardLink(true);
      char target[64]; assert(machinePreview(sq("d2"), sq("d4"), target));
      boardReport(target); assert(!lifting && virtualGame.board[sq("d4")] == 'P');
      pump(1500); physicalMove(true, "g8", "f6");
    }
    if (!strcmp(scenario, "virtual_cutoff")) {
      move(false, "d2", "d4"); assert(stoppedScans == 1);
      assert(!machineGatewayWantsBoard() && !machineGatewaySelectPhysical());
      machineGatewayResetGame(); assert(!machineGatewayWantsBoard());
      assert(!machineGatewaySelectPhysical()); // New Game does not reopen radio search.
    }
    if (!strcmp(scenario, "soft_newgame")) {
      move(true, "e2", "e4"); move(false, "e7", "e5");
      registers[4] = 7; registers[2] = 3;
      const unsigned saved = recorderRestarts;
      const unsigned cancelled = stoppedScans;
      assert(machineGatewayNewgameAllowed());
      assert(machineGatewaySoftNewgame());
      assert(newgameHold && !players.assigned() && !lifting && !halted);
      assert(registers[4] == 7 && registers[2] == 3);
      assert(recorderRestarts == saved + 1 && stoppedScans == cancelled);
      assert(virtualGame.board[sq("e2")] == 'P');
      assert(virtualGame.board[sq("e7")] == 'p');
      assert(!cableStatuses.empty() && cableStatuses.back() == notifications.back());
      suggest(true, "d2", "d4"); assert(hints == 0);
      assert(machineGatewayNewgamePublished());
      machineGatewayNewgameFinish(); assert(!newgameHold);
      subscribed = false;
      assert(!machineGatewayNewgameAllowed() && !machineGatewaySoftNewgame());
      subscribed = true;
      machineGatewayBoardLink(true);
      assert(!machineGatewayNewgameAllowed() && !machineGatewaySoftNewgame());
    }
    if (!strcmp(scenario, "reset")) {
      move(false, "d2", "d4");
      suggest(true, "g8", "f6"); pump(400); assert(lifting);
      uint8_t reset[] = {'T', 0, 0};
      computeModeBChecksumHex(reset + 1, reset, 1, false);
      Frame before; memcpy(before.data(), machineGatewayStatus(), 67);
      const size_t sent = notifications.size(), cableSent = cableStatuses.size();
      registers[4] = 7;
      assert(serverResetLeavesTransportUntouched());
      assert(recorderRestarts == 0 && lifting && players.assigned());
      assert(registers[4] == 7 && !memcmp(before.data(), machineGatewayStatus(), 67));
      assert(notifications.size() == sent && cableStatuses.size() == cableSent);
      machineGatewayCommand(reset, sizeof(reset));
      assert(recorderRestarts == 1 && !lifting && !halted && !players.assigned());
      assert(!pendingLeds.count && !hints && candidateFrom == -1);
      assert(registers[4] == 0x0f);
      assert(machineWhiteToMove() && memcmp(virtualGame.board, kStartBoard, 64) == 0);
      assert(notifications.back() == cableStatuses.back());
      assert(piece(notifications.back(), sq("d2")) == 'P');
      assert(piece(notifications.back(), sq("d4")) == '.');
      machineGatewayCommand(reset, sizeof(reset));
      assert(recorderRestarts == 1);
      pump(1500);
      move(true, "e2", "e4");
      subscribed = false;
      machineGatewayResetGame();
      assert(recorderRestarts == 2 && piece(cableStatuses.back(), sq("e2")) == 'P');
      assert(memcmp(machineGatewayStatus(), cableStatuses.back().data(), 67) == 0);
    }
    if (!strcmp(scenario, "white")) { move(true, "e2", "e4"); move(false, "e7", "e5"); }
    if (!strcmp(scenario, "black")) { move(false, "d2", "d4"); move(true, "g8", "f6"); }
    if (!strcmp(scenario, "early")) {
      suggest(false, "d2", "d4"); pump(400); assert(lifting);
      suggest(true, "g8", "f6"); assert(pendingLeds.count == 1);
      pump(6500);
      assert(!halted && !lifting && !pendingLeds.count);
      assert(virtualGame.board[sq("d4")] == 'P' && virtualGame.board[sq("f6")] == 'n');
      assert(completePositions.size() == 3 && notifications.size() == 5);
    }
    if (!strcmp(scenario, "capture")) {
      move(true, "e2", "e4"); move(false, "d7", "d5");
      const size_t n = notifications.size(); move(true, "e4", "d5", 3);
      assert(piece(notifications[n + 1], sq("d5")) == '.');
    }
    if (!strcmp(scenario, "ep")) {
      move(false, "e2", "e4"); move(true, "a7", "a6");
      move(false, "e4", "e5"); move(true, "d7", "d5");
      const size_t n = notifications.size(); move(false, "e5", "d6", 3);
      assert(piece(notifications[n + 1], sq("d5")) == '.');
    }
    if (!strcmp(scenario, "castle")) {
      move(true, "e2", "e4"); move(false, "e7", "e5");
      move(true, "g1", "f3"); move(false, "b8", "c6");
      move(true, "f1", "c4"); move(false, "g8", "f6");
      size_t n = notifications.size(); move(true, "e1", "g1", 4);
      assert(piece(notifications[n + 1], sq("g1")) == 'K');
      assert(piece(notifications[n + 1], sq("h1")) == 'R');
      assert(piece(notifications[n + 2], sq("h1")) == '.');
      move(false, "f8", "e7"); move(true, "d2", "d3");
      n = notifications.size(); move(false, "e8", "g8", 4);
      assert(piece(notifications[n + 1], sq("g8")) == 'k');
      assert(piece(notifications[n + 1], sq("h8")) == 'r');
    }
    if (!strcmp(scenario, "splash") || !strcmp(scenario, "reconnect")) {
      suggest(false, "d2", "d4"); pump(400); assert(lifting);
      const size_t n = notifications.size();
      if (!strcmp(scenario, "splash")) {
        uint8_t all[167]; memset(all, 'C', sizeof(all)); all[0] = 'L'; all[1] = all[2] = '2';
        serverLed(all, 167);
        assert(!halted && lifting && pendingLeds.count == 0);
      } else {
        subscribed = false; pump(2000); assert(lifting && notifications.size() == n);
        assert(machineGatewayAcceptSoftware() && !machineGatewaySelectPhysical());
        subscribed = true; chesslinkServerPublishStatus(machineGatewayStatus());
      }
      pump(3000); assert(!halted && !lifting && virtualGame.board[sq("d4")] == 'P');
      move(true, "g8", "f6");
    }
  }
  printf("Machine gateway test passed: %s\n", scenario);
}
