#include "../include/millennium_link_watchdog.h"
#include <cassert>
#include <cstdio>

int main() {
  using Action = MillenniumLinkWatchdog::Action;
  MillenniumLinkWatchdog watch;
  watch.reset(0);
  assert(watch.poll(9999) == Action::None);
  assert(watch.poll(10000) == Action::Probe); // silence only asks, never drops
  watch.noteWrite(true);
  assert(watch.poll(14999) == Action::None);
  watch.noteReply(14999, true); // identical board position is a valid reply
  assert(watch.poll(15000) == Action::None);
  assert(watch.poll(24999) == Action::Probe);
  assert(watch.poll(29999) == Action::Probe);
  assert(watch.poll(34998) == Action::None);
  assert(watch.poll(34999) == Action::Disconnect);

  // ATT success does not establish notification health. Unrelated replies
  // cannot answer a pending S probe; an actual s reply can.
  watch.reset(0);
  watch.poll(10000);
  watch.noteWrite(true);
  watch.noteReply(12000, false);
  assert(watch.poll(15000) == Action::Probe);
  watch.noteReply(19999, true);
  assert(watch.poll(20000) == Action::None);

  // Regular protocol replies keep a working, motionless board connected.
  watch.reset(0);
  for (uint32_t t = 1000; t <= 60000; t += 1000) {
    watch.noteReply(t, false);
    assert(watch.poll(t) == Action::None);
  }

  watch.noteWrite(false);
  watch.noteWrite(false);
  assert(watch.poll(60000) == Action::None);
  watch.noteWrite(true); // a transient failure is recoverable
  watch.noteWrite(false);
  watch.noteWrite(false);
  assert(watch.poll(60000) == Action::None);
  watch.noteWrite(false);
  assert(watch.poll(60000) == Action::Disconnect);
  watch.reset(70000); // reconnect clears all previous failures/probes
  assert(watch.poll(70000) == Action::None);

  watch.reset(0xfffffff0u);
  assert(watch.poll(0xfffffff0u + 9999u) == Action::None);
  assert(watch.poll(0xfffffff0u + 10000u) == Action::Probe);
  assert(watch.poll(0xfffffff0u + 15000u) == Action::Probe);
  assert(watch.poll(0xfffffff0u + 20000u) == Action::Disconnect);
  puts("PASS: silent peer probes, unchanged status, retries, write failures, reset, rollover");
}
