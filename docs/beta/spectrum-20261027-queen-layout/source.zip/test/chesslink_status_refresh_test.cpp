#include "../include/chesslink_status_refresh.h"

#include <assert.h>
#include <stdio.h>

int main() {
  ChesslinkStatusRefresh refresh;
  assert(!refresh.due(10000));

  // BearChess configuration: coalesce W01/W02/W03, then let V and LED
  // commands finish before sending the current position once.
  refresh.schedule(100);
  refresh.schedule(200);
  refresh.schedule(300);
  refresh.noteTraffic(450);
  assert(!refresh.due(949));
  assert(refresh.due(950));
  refresh.reset();
  assert(!refresh.due(2000));

  // Dojo requests S after configuring: a successful reply satisfies the
  // refresh, even if a later X command extends the receive activity.
  refresh.schedule(3000);
  refresh.reset();
  refresh.noteTraffic(3200);
  assert(!refresh.due(5000));

  // A failed send does not consume the pending refresh; retry after idle.
  refresh.schedule(6000);
  assert(refresh.due(6500));
  refresh.noteTraffic(6500);
  assert(!refresh.due(6999));
  assert(refresh.due(7000));

  // Disconnect cancels it; a later session can schedule its own refresh.
  refresh.reset();
  assert(!refresh.due(9000));
  refresh.schedule(10000);
  assert(refresh.due(10500));

  // millis() rollover must not cause an immediate or missing refresh.
  refresh.schedule(UINT32_MAX - 99);
  assert(!refresh.due(399));
  assert(refresh.due(400));
  puts("PASS: configuration bursts, explicit status, retry, reconnect, rollover");
}
