#include <cassert>
#include <cstdio>
#include <initializer_list>
#include "../experiments/machine/castle_motion.h"
#include "../experiments/machine/delivery_gate.h"
#include "../experiments/machine/pending_leds.h"
#include "../experiments/machine/players.h"
#include "../.pio/machine_actual.inc"
#include "../experiments/machine/software_led_orientation.h"
#include "../.pio/machine_server_rotation.inc"

bool halted = false, lifting = false, subscribed = true;
MachinePendingLeds pendingLeds;
MachinePlayers players;
uint64_t hints = 0;
uint64_t lastMoveFields = 0;
uint32_t conflictStartedAt = 0, conflictLastAt = 0;
uint32_t fieldSeenAt[64] = {};
uint32_t hintAt = 0, candidateAt = 0, fakeNow = 100;
int candidateFrom = -1, candidateTo = -1;
uint32_t millis() { return fakeNow; }
bool chesslinkServerNotifyEnabled() { return subscribed; }
struct Log { template<class... T> void printf(const char*, T...) {} void println(const char*) {} } Serial;
int __builtin_popcountll(uint64_t n) { int c = 0; while(n) { n &= n-1; ++c; } return c; }
#include "../.pio/machine_led_actual.inc"

bool castlingMotion = false;
int movementStage = 0, recorderRestarts = 0, published = 0;
uint32_t liftedAt = 0;
char publishedBoard[64];
void machineRecorderRestart() { ++recorderRestarts; }
void publish(const char board[64]) { memcpy(publishedBoard, board, 64); ++published; }
#include "../.pio/machine_restart_actual.inc"

uint64_t bit(const char* sq) { return uint64_t(1) << ((sq[1]-'1')*8 + sq[0]-'a'); }
void play(const char* from, const char* to) {
  int f = -1, t = -1;
  assert(machineFindMove(bit(from) | bit(to), f, t) == 1);
  machineCommit(f, t);
}
int main() {
  players.assignFirst(true);
  MachineDeliveryGate gate;
  assert(!gate.ready(10000, 1000));
  gate.sent(100); assert(!gate.ready(2000, 1000));
  gate.sent(300); gate.sent(500);
  assert(!gate.ready(1099, 1000) && gate.ready(1100, 1000));
  gate.reset(); assert(!gate.ready(10000, 1000));
  gate.sent(0xfffffff0u); gate.sent(0xfffffff5u); gate.sent(0xfffffffau);
  assert(gate.ready(1000, 1000));
  machineReset();
  int f = -1, t = -1;
  uint8_t frame[167];
  play("e2", "e4");
  // Echo of White's lifted e2 pawn is feedback, not a black reply.
  assert(pendingLeds.add(bit("e2")));
  assert(pendingLeds.resolve(machineFindMove, f, t) == 0);
  assert(!machineCouldBeMoveFields(bit("e2")));
  pendingLeds.clear();
  assert(pendingLeds.add(bit("e7")));
  assert(pendingLeds.resolve(machineFindMove, f, t) == 0);
  assert(machineCouldBeMoveFields(bit("e7")));
  pendingLeds.clear();
  lifting = true; candidateFrom = 52; candidateTo = 36;
  const uint8_t earlyReply[] = {6, 21};
  encodeLedFrame(earlyReply, 2, frame, false);
  led(true, frame);
  assert(pendingLeds.count == 1 && candidateFrom == 52 && candidateTo == 36);
  assert(!machineWhiteToMove() && virtualGame.board[6] == 'N');
  machineCommit(52, 36); lifting = false;
  assert(pendingLeds.resolve(machineFindMove, f, t) == 1 && f == 6 && t == 21);
  assert(pendingLeds.add(bit("e8") | bit("f8"))); // Later correction does not overwrite reply.
  assert(pendingLeds.resolve(machineFindMove, f, t) == 1 && f == 6 && t == 21);
  pendingLeds.clear();
  assert(pendingLeds.add(bit("g1")) && pendingLeds.add(bit("f3")));
  assert(pendingLeds.resolve(machineFindMove, f, t) == 1);
  assert(pendingLeds.add(bit("b1") | bit("c3")));
  assert(pendingLeds.resolve(machineFindMove, f, t) == 2);
  pendingLeds.clear();
  for (int i = 0; i < 8; ++i) assert(pendingLeds.add(uint64_t(1) << i));
  assert(pendingLeds.add(1) && !pendingLeds.add(uint64_t(1) << 8));
  pendingLeds.clear(); machineReset(); resetHints();
  const uint8_t pair[] = {12, 28};
  encodeLedFrame(pair, 2, frame, false);
  led(false, frame); assert(candidateFrom == -1); // Wrong engine's turn.
  subscribed = false; led(true, frame); assert(candidateFrom == -1);
  subscribed = true; led(true, frame);
  assert(candidateFrom == 12 && candidateTo == 28); // Includes geometric e3 ghost.
  resetHints();
  encodeLedFrame(pair, 1, frame, false); led(true, frame); assert(candidateFrom == -1);
  fakeNow += 100;
  encodeLedFrame(pair + 1, 1, frame, false); led(true, frame);
  assert(candidateFrom == 12 && candidateTo == 28); // Alternating Phoenix frames.
  const uint32_t firstCandidateAt = candidateAt;
  fakeNow += 50; led(true, frame); assert(candidateAt == firstCandidateAt);
  resetHints();
  // Hardware regression: echoed e2/e4 must age out while e7/e5 keep blinking.
  machineCommit(12, 28);
  const uint8_t sequence[] = {12, 28, 52, 36, 52, 36, 52, 36, 52};
  for (uint8_t sq : sequence) {
    fakeNow += 400;
    encodeLedFrame(&sq, 1, frame, false);
    led(false, frame);
  }
  assert(candidateFrom == 52 && candidateTo == 36);
  assert(hints == (bit("e7") | bit("e5")));
  machineReset(); resetHints();
  assert(machineFindMove(bit("e2"), f, t) == 0);
  assert(machineFindMove(bit("e7") | bit("e5"), f, t) == 0);
  assert(machineFindMove(bit("e2") | bit("e5"), f, t) == 0);
  assert(machineFindMove(bit("e2") | bit("e3") | bit("e4"), f, t) == 1);
  play("e2", "e4"); play("c7", "c5"); play("g1", "f3"); play("d7", "d6");
  play("d2", "d4");
  char removed[64];
  assert(machineCapturedSquare(34, 27) == 27);
  assert(machineCaptureRemoved(34, 27, removed));
  assert(removed[34] == '.' && removed[27] == '.');
  assert(virtualGame.board[34] == 'p' && virtualGame.board[27] == 'P');
  lastMoveFields = bit("d2") | bit("d4");
  for (int i = 0; i < 8; ++i) { fakeNow += 1000; assert(!observeCableConflict(bit("d4"))); }
  assert(conflictStartedAt == 0);
  play("c5", "d4");
  assert(virtualGame.board[27] == 'p' && virtualGame.board[34] == '.');

  machineReset();
  play("e2", "e4"); play("a7", "a6"); play("e4", "e5"); play("d7", "d5");
  assert(machineCapturedSquare(36, 43) == 35);
  assert(machineCaptureRemoved(36, 43, removed));
  assert(removed[36] == '.' && removed[35] == '.' && removed[43] == '.');
  assert(machineFindMove(bit("e5") | bit("d5") | bit("d6"), f, t) == 1);
  play("e5", "d6");
  assert(virtualGame.board[35] == '.' && virtualGame.board[43] == 'P');

  machineReset();
  play("e2", "e4"); play("e7", "e5"); play("g1", "f3"); play("b8", "c6");
  play("f1", "e2"); play("g8", "f6");
  assert(machineFindMove(bit("e1") | bit("g1") | bit("h1") | bit("f1"), f, t) == 1);
  machineCommit(f, t);
  assert(virtualGame.board[6] == 'K' && virtualGame.board[5] == 'R');

  // Four observable snapshots, both colours and both castling directions.
  for (int base : {0, 56}) for (int destination : {2, 6}) {
    char before[64], stage[64]; memset(before, '.', 64);
    before[base + 4] = base == 0 ? 'K' : 'k';
    const int rf = base + (destination == 6 ? 7 : 0);
    const int rt = base + (destination == 6 ? 5 : 3);
    before[rf] = base == 0 ? 'R' : 'r';
    assert(machineCastleStage(before, stage, base + 4, base + destination, 0));
    assert(stage[base + 4] == '.' && stage[base + destination] == '.' && stage[rf] == before[rf]);
    assert(machineCastleStage(before, stage, base + 4, base + destination, 1));
    assert(stage[base + destination] == before[base + 4] && stage[rf] == before[rf] && stage[rt] == '.');
    assert(machineCastleStage(before, stage, base + 4, base + destination, 2));
    assert(stage[base + destination] == before[base + 4] && stage[rf] == '.' && stage[rt] == '.');
    assert(machineCastleStage(before, stage, base + 4, base + destination, 3));
    assert(stage[base + destination] == before[base + 4] && stage[rf] == '.' && stage[rt] == before[rf]);
  }

  machineReset();
  memset(virtualGame.board, '.', 64);
  virtualGame.board[4] = 'K'; virtualGame.board[60] = 'k'; virtualGame.board[48] = 'P';
  assert(machineFindMove(bit("a7") | bit("a8"), f, t) == 4);
  machineReset();
  play("f2", "f3"); play("e7", "e5"); play("g2", "g4"); play("d8", "h4");
  ChessMove moves[128];
  assert(inCheck(virtualGame, true) && generateLegalMoves(virtualGame, moves, 128) == 0);
  lastMoveFields = bit("e1") | bit("g1") | bit("h1") | bit("f1");
  fakeNow = 10000;
  assert(!observeCableConflict(bit("e1")));
  for (int i = 0; i < 4; ++i) { fakeNow += 1000; assert(!observeCableConflict(bit("f1"))); }
  fakeNow += 1000; assert(observeCableConflict(bit("e1")) && halted);
  halted = lifting = false; resetHints(); machineReset(); players.reset();
  // Opening fragments from different endpoints must never combine.
  encodeLedFrame(pair, 1, frame, false); led(false, frame);
  encodeLedFrame(pair + 1, 1, frame, false); led(true, frame);
  assert(!players.assigned() && candidateFrom == -1);
  encodeLedFrame(pair + 1, 1, frame, false); led(false, frame);
  assert(players.whiteEndpoint == 0 && candidateFrom == 12 && candidateTo == 28);
  machineCommit(12, 28); resetHints();
  const uint8_t blackPair[] = {52, 36};
  encodeLedFrame(blackPair, 2, frame, false);
  led(false, frame); assert(candidateFrom == -1);
  led(true, frame); assert(candidateFrom == 52 && candidateTo == 36);
  lifting = true;
  encodeLedFrame(earlyReply, 2, frame, false); led(false, frame);
  assert(pendingLeds.count == 1); // Cable's next white move is buffered too.
  pendingLeds.clear(); lifting = false;
  players.reset(); machineReset(); resetHints();
  encodeLedFrame(pair, 2, frame, false); led(true, frame);
  assert(players.whiteEndpoint == 1 && candidateFrom == 12);
  machineCommit(12, 28);
  halted = lifting = castlingMotion = true; movementStage = 2;
  pendingLeds.add(bit("e7")); lastMoveFields = bit("e4");
  conflictStartedAt = conflictLastAt = 999;
  machineRestartGame();
  assert(recorderRestarts == 1 && published == 1);
  assert(!halted && !lifting && !castlingMotion && movementStage == 0);
  assert(!players.assigned() && !players.opening[0] && !players.opening[1]);
  assert(!pendingLeds.count && !hints && candidateFrom == -1);
  assert(!lastMoveFields && !conflictStartedAt && !conflictLastAt);
  assert(machineWhiteToMove() && memcmp(publishedBoard, kStartBoard, 64) == 0);
  encodeLedFrame(pair, 2, frame, false); led(false, frame);
  assert(players.whiteEndpoint == 0); // Fresh game can reverse the assignment.
  // MACHINE LED capture is AFTER the shared server rotation, not BLE wire input.
  // It decodes b1-c3 although BearChess requested ...Ng8-f6.
  const char captured[] = "L22000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000033330000000000CCCC33330000000000CCCC000000000000000000000000000000004C";
  static_assert(sizeof(captured) == 168, "Captured frame must be 167 bytes");
  uint8_t serverFrame[167], restored[167];
  machineReset(); players.reset(); players.assignFirst(false); resetHints();
  play("d2", "d4");
  memcpy(serverFrame, captured, 167);
  led(true, serverFrame);
  assert(candidateFrom == -1 && hints == (bit("b1") | bit("c3")));
  resetHints();
  machineRestoreSoftwareLedFrame(serverFrame, restored);
  uint8_t recaptured[167];
  sharedServerRotation(restored, recaptured);
  assert(memcmp(recaptured, captured, 167) == 0);
  led(true, restored);
  assert(candidateFrom == 62 && candidateTo == 45);
  // White software still selects e2-e4 through the same BLE boundary.
  machineReset(); players.reset(); resetHints();
  encodeLedFrame(pair, 2, frame, false);
  sharedServerRotation(frame, serverFrame);
  machineRestoreSoftwareLedFrame(serverFrame, restored);
  led(true, restored);
  assert(players.whiteEndpoint == 1 && candidateFrom == 12 && candidateTo == 28);
  // Every corner, including the centre, and each LED colour/phase byte must
  // survive the shared-server + machine-adapter boundary unchanged.
  for (int i = 0; i < 167; ++i) frame[i] = uint8_t(i);
  sharedServerRotation(frame, serverFrame);
  machineRestoreSoftwareLedFrame(serverFrame, restored);
  assert(memcmp(frame, restored, 167) == 0);
  // A black reply arriving while the cable's white move is still lifted
  // must be buffered in canonical coordinates, then resolve after d2-d4.
  machineReset(); players.reset(); players.assignFirst(false); resetHints();
  pendingLeds.clear(); lifting = true; candidateFrom = 11; candidateTo = 27;
  machineRestoreSoftwareLedFrame(reinterpret_cast<const uint8_t*>(captured), restored);
  led(true, restored);
  assert(pendingLeds.count == 1 && candidateFrom == 11 && candidateTo == 27);
  machineCommit(11, 27); lifting = false;
  assert(pendingLeds.resolve(machineFindMove, f, t) == 1 && f == 62 && t == 45);
  puts("Machine tests passed: both software colours, captured black knight, turn order, capture, en passant, castling, mate.");
}
