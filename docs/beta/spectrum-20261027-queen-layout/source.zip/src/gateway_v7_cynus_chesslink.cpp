#include <Arduino.h>
#include <NimBLEDevice.h>

#include <algorithm>

#include "board_driver.h"
#include "chesslink_server.h"
#include "cynus_board.h"
#include "pgn_recorder.h"

// esp32-c3-superminiV7_CynusChessLinkOnly: a dedicated, deliberately narrow
// build -- Cynus robot (BLE central) against the ChessLink BLE masquerade
// role ONLY. No cable/Millennium/Phoenix relay, no Chessnut/iChessOne board
// support, no BT-BT queen-gesture mode selection (there is only one mode
// here, so nothing to select). Built at the user's own request, 2026-09-04,
// after real-hardware testing that day found and fixed a bug specific to
// running Cynus+ChessLink alongside Chessnut on the shared multi-board
// gateway (main.cpp): both masquerade services' GATT characteristics stay
// live simultaneously regardless of which mode is actually selected, and a
// multi-protocol-aware BLE client (BearChess) discovers and probes both,
// confirmed on real hardware even on a connection with no prior history of
// this device. A single-protocol build sidesteps that whole class of bug by
// construction -- there is only ever one service to find.
//
// Keeps every Cynus-specific feature from the full gateway: robot move
// execution (with echo protection against replaying the human's own move),
// castling/king-gesture handling, illegal-move-check auto-disable, PGN
// recording + USB/BLE retrieval. ChessLink status output uses the shared
// chesslink_server.cpp implementation and preserves Mode-B wire order.

namespace {

constexpr int kStatusLedPin = 8;
constexpr uint32_t kMonitorBaud = 115200;
constexpr uint32_t kReconnectIntervalMs = 3000;

uint8_t cachedBoardStatus[kModeBStatusFrameLength] = {};
bool haveCachedBoardStatus = false;
uint8_t lastLoggedStatus[kModeBStatusFrameLength] = {};
bool haveLoggedStatus = false;
bool ledsAwaitingClear = false;

uint32_t lastConnectAttemptMs = 0;
bool cynusConnected = false;
volatile bool connectInProgress = false;

enum class LedState : uint8_t { Searching, Connected };
volatile LedState ledState = LedState::Searching;

void statusLedTask(void*) {
  bool ledOn = false;
  uint32_t lastChangeMs = 0;
  for (;;) {
    const uint32_t nowMs = millis();
    const LedState state = ledState;
    if (state == LedState::Searching) {
      if (static_cast<uint32_t>(nowMs - lastChangeMs) >= 250) {
        ledOn = !ledOn;
        lastChangeMs = nowMs;
      }
    } else {
      ledOn = true;
    }
    digitalWrite(kStatusLedPin, ledOn ? LOW : HIGH);  // onboard LED is active low
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// Case-insensitive substring search -- BLE devices vary the exact advertised
// name (model suffix, MAC-derived suffix, etc.) so an exact/case-sensitive
// match is too brittle to rely on. Ported from main.cpp's own helper.
bool containsCaseInsensitive(const std::string& haystack, const char* needle) {
  std::string lowerHaystack = haystack;
  std::transform(lowerHaystack.begin(), lowerHaystack.end(), lowerHaystack.begin(), ::tolower);
  std::string lowerNeedle = needle;
  std::transform(lowerNeedle.begin(), lowerNeedle.end(), lowerNeedle.begin(), ::tolower);
  return lowerHaystack.find(lowerNeedle) != std::string::npos;
}

bool scanForCynus(NimBLEAddress& address) {
  Serial.println("BLE scan: looking for a Cynus board ...");
  NimBLEScan* scan = NimBLEDevice::getScan();
  scan->setActiveScan(true);
  NimBLEScanResults results = scan->getResults(5000, false);

  for (int i = 0; i < results.getCount(); ++i) {
    const NimBLEAdvertisedDevice* device = results.getDevice(i);
    if (!device->haveName()) continue;
    if (containsCaseInsensitive(device->getName(), kCynusBoardName)) {
      address = device->getAddress();
      Serial.printf("BLE board found: %s (%s, addr type %d)\r\n", device->getName().c_str(),
                    address.toString().c_str(), address.getType());
      scan->clearResults();
      return true;
    }
  }

  scan->clearResults();
  Serial.println("No matching BLE board found.");
  return false;
}

bool connectToBoard() {
  ledState = LedState::Searching;
  NimBLEAddress address;
  if (!scanForCynus(address)) return false;
  if (!cynusConnect(address)) return false;

  cynusConnected = true;
  ledState = LedState::Connected;
  haveCachedBoardStatus = false;
  haveLoggedStatus = false;
  ledsAwaitingClear = false;
  return true;
}

// The underlying BLE library's connect() call has no internal timeout and
// can block forever if a peer accepts the link at the radio level but never
// completes the GATT-open handshake. Running each attempt on its own task
// keeps a stuck connect from freezing loop().
void connectTask(void*) {
  connectToBoard();
  connectInProgress = false;
  vTaskDelete(nullptr);
}

}  // namespace

// Only ever Cynus in this build -- kept as a real function (not a constant)
// so chesslink_server.cpp/pgn_recorder.cpp/board_driver_v7.cpp's existing
// currentBoardType()-based dispatch code works completely unchanged.
BoardType currentBoardType() { return cynusConnected ? BoardType::Cynus : BoardType::Unknown; }

const uint8_t* cachedBoardStatusBytes() { return haveCachedBoardStatus ? cachedBoardStatus : nullptr; }

void onBoardStatusFrame(const uint8_t frame[kModeBStatusFrameLength]) {
  if (!haveLoggedStatus || memcmp(lastLoggedStatus, frame, kModeBStatusFrameLength) != 0) {
    memcpy(lastLoggedStatus, frame, kModeBStatusFrameLength);
    haveLoggedStatus = true;
    Serial.print("[BOARD STATUS] ");
    Serial.write(frame, kModeBStatusFrameLength);
    Serial.println();
  }

  const bool wasFirstStatus = !haveCachedBoardStatus;
  memcpy(cachedBoardStatus, frame, kModeBStatusFrameLength);
  haveCachedBoardStatus = true;

  // Purely a passive observer -- only copies the frame, all actual move
  // inference/PGN work happens later in pgnRecorderPoll(), off this
  // time-critical path.
  pgnRecorderOnBoardStatus(frame);

  // Forwards to the connected ChessLink client if one is subscribed;
  // otherwise a safe no-op (see chesslinkServerPublishStatus()'s own
  // comment for the 2026-09-04 wire-order fix this now includes).
  chesslinkServerPublishStatus(frame);

  if (wasFirstStatus || ledsAwaitingClear) {
    cynusClearLeds();
    ledsAwaitingClear = false;
  }
}

void setup() {
  Serial.begin(kMonitorBaud);
  delay(1500);

  pinMode(kStatusLedPin, OUTPUT);
  digitalWrite(kStatusLedPin, HIGH);
  xTaskCreate(statusLedTask, "status-led", 1536, nullptr, 1, nullptr);

  Serial.println("\r\nBluetoothMax -- Cynus + ChessLink only (V7)");
  Serial.println("BLE only: no cable, no Chessnut/Millennium/iChessOne, no mode selection.");

  NimBLEDevice::init("BluetoothMax");

  chesslinkServerInit();
  chesslinkServerStart();
  pgnRecorderInit();
}

void loop() {
  pgnRecorderPoll();
  chesslinkServerPoll();

  if (cynusConnected && cynusIsConnected()) {
    cynusPoll();
  } else if (cynusConnected) {
    cynusConnected = false;
    ledState = LedState::Searching;
  }

  const uint32_t nowMs = millis();
  if (!cynusConnected && !connectInProgress &&
      static_cast<uint32_t>(nowMs - lastConnectAttemptMs) >= kReconnectIntervalMs) {
    lastConnectAttemptMs = nowMs;
    connectInProgress = true;
    xTaskCreate(connectTask, "board-connect", 8192, nullptr, 1, nullptr);
  }

  static uint32_t lastStatusMs = 0;
  if (static_cast<uint32_t>(nowMs - lastStatusMs) >= 10000) {
    Serial.printf("Gateway: Cynus=%s, ChessLink client=%s\r\n",
                  cynusConnected ? "connected" : "offline",
                  chesslinkServerConnected() ? "connected" : "none");
    lastStatusMs = nowMs;
  }

  delay(1);
}
