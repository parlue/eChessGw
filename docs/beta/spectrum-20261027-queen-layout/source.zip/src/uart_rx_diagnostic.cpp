#include <Arduino.h>
#include <driver/gpio.h>

// Standalone PCB commissioning: no BLE and no cable writes.
// Former TX pin is undriven; all diagnostics go to native USB CDC.
HardwareSerial cableRx(1);
static uint32_t total = 0, lastSummary = 0, lastByte = 0;
static uint8_t buffer[64];
static size_t used = 0;

static void dump() {
  if (!used) return;
  char line[360];
  size_t pos = snprintf(line, sizeof(line), "[RX t=%lu n=%u] HEX:",
    (unsigned long)millis(), (unsigned)used);
  for (size_t i = 0; i < used; ++i)
    pos += snprintf(line + pos, sizeof(line) - pos, " %02X", buffer[i]);
  pos += snprintf(line + pos, sizeof(line) - pos, " ASCII7: ");
  for (size_t i = 0; i < used; ++i) {
    const uint8_t c = buffer[i] & 0x7f;
    line[pos++] = c >= 32 && c <= 126 ? c : '.';
  }
  line[pos++] = '\r'; line[pos++] = '\n';
  Serial.write((const uint8_t*)line, pos);
  used = 0;
}

void setup() {
  cableRx.setRxBufferSize(8192);
  cableRx.begin(38400, SERIAL_8N1, 21, 20);
  gpio_reset_pin(GPIO_NUM_20);
  gpio_set_direction(GPIO_NUM_20, GPIO_MODE_INPUT);
  Serial.begin(115200);
  delay(1500);
  Serial.println("[RX DIAG] RX=GPIO21 GPIO20=input; 38400 8N1 captures parity bit; NO cable writes; BLE off");
}

void loop() {
  for (int budget = 0; budget < 512 && cableRx.available(); ++budget) {
    buffer[used++] = (uint8_t)cableRx.read();
    ++total; lastByte = millis();
    if (used == sizeof(buffer)) dump();
  }
  if (used && millis() - lastByte >= 20) dump();
  if (millis() - lastSummary >= 2000) {
    lastSummary = millis();
    Serial.printf("[RX DIAG] t=%lu received=%lu bytes; cable TX silent\r\n",
      (unsigned long)lastSummary, (unsigned long)total);
  }
  delay(1);
}
