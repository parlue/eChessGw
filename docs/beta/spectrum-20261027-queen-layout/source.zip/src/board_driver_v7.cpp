#include "board_driver.h"

#include <cstring>

#include "cynus_board.h"

// Trimmed for the esp32-c3-superminiV7_CynusChessLinkOnly environment
// (Cynus robot + ChessLink BLE masquerade only, no cable/Millennium/
// Chessnut/iChessOne support at all) -- ported from board_driver.cpp,
// keeping only what a Cynus-only build actually reaches. decodeKingLedFrame()
// and encodeLedFrame() are Chessnut/iChessOne/Millennium-only in the full
// project (Cynus decodes 'L' frames itself, see cynus_board.cpp) and are
// dropped entirely here rather than kept as dead code.

void resetKingLedFrameBaseline() {
  // No-op here too -- see board_driver.cpp's own comment. Kept only because
  // main-equivalent code calls it unconditionally on every board (re)connect;
  // Cynus's own driver has no baseline state to reset.
}

void dispatchLedFrameToBoard(BoardType type, const uint8_t frame167[167]) {
  if (type == BoardType::Cynus) {
    // Cynus's own driver decodes the raw frame itself (engineSide-aware,
    // with a stability wait) -- see cynus_board.cpp.
    cynusHandleLedFrame(frame167);
  }
}

// Shows a 3-second confirmation signal after a king-gesture result
// (win/loss/draw, see pgn_recorder.cpp's detectKingGestureResult()).
// Cynus has no LEDs, so it shows the result as text instead. result must be
// one of detectKingGestureResult()'s own return values ("1-0", "0-1",
// "1/2-1/2"). Call clearKingGestureResultConfirmation() once the 3-second
// hold is over.
void showKingGestureResultConfirmation(BoardType type, const char* result) {
  if (type != BoardType::Cynus) return;
  // "1/2:1/2" (7 characters) confirmed by the user to fit the display, same
  // as "1:0"/"0:1".
  const char* text = (strcmp(result, "1-0") == 0)   ? "1:0"
                      : (strcmp(result, "0-1") == 0) ? "0:1"
                                                      : "1/2:1/2";
  cynusShowText(text);
}

void clearKingGestureResultConfirmation(BoardType type) {
  if (type == BoardType::Cynus) cynusShowText("play");
}

void clearBoardLeds(BoardType type) {
  if (type == BoardType::Cynus) cynusClearLeds();
}
