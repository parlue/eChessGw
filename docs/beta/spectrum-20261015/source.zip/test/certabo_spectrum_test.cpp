#include "certabo_led_identity.h"
#include "certabo_spectrum_leds.h"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <string>

using certabo::LedType;
void feed(certabo::LedIdentity& id,const std::string& s) {
  for (unsigned char c:s) id.feed(c);
}
int main(int argc,char** argv) {
  certabo::LedIdentity id;
  assert(id.type()==LedType::Unknown);
  feed(id,"DEBUG\r\nLED\r\n:1 D 0 0\r\n");
  assert(id.type()==LedType::Unknown);
  feed(id,"L"); assert(id.type()==LedType::Unknown);
  feed(id,"\r\n"); assert(id.type()==LedType::Mono);
  feed(id,":1 2 3\r\nL\r\n"); assert(id.type()==LedType::Mono);
  feed(id,"D\r\n"); assert(id.conflict() && id.type()==LedType::Unknown);
  feed(id,"L\r\n"); assert(id.type()==LedType::Unknown);
  id.reset(); feed(id,"D:"); assert(id.type()==LedType::Rgb);
  id.reset(); feed(id,"D"); id.resetPending(); feed(id,"\r\n");
  assert(id.type()==LedType::Unknown);
  const std::string sample=":1 2 3\r\nD\r\n:4 5 6\r\n";
  for(size_t split=0;split<=sample.size();++split) {
    id.reset(); feed(id,sample.substr(0,split)); feed(id,sample.substr(split));
    assert(id.type()==LedType::Rgb);
  }
  uint8_t mask[8]{}, out[certabo::spectrum::kCommandBytes+1];
  for(int square=0;square<64;++square) {
    memset(mask,0,8); mask[7-square/8]=uint8_t(1u<<(square%8));
    memset(out,0xa5,sizeof(out)); certabo::spectrum::encode(mask,out);
    assert(out[0]==255 && out[1]==85 && out[245]==13 && out[246]==10 && out[247]==0xa5);
    int lit=0;
    for(int led=0;led<81;++led) {
      assert(out[3+led*3]==0 && out[4+led*3]==0);
      if(out[2+led*3]) {assert(out[2+led*3]==204); ++lit;}
    }
    assert(lit==4);
    // Independently check the four named board corners from the PDF.
    if(square==0) for(int led:{8,9,17,18}) assert(out[2+(led-1)*3]==204);
    if(square==7) for(int led:{1,2,10,11}) assert(out[2+(led-1)*3]==204);
    if(square==56) for(int led:{71,72,80,81}) assert(out[2+(led-1)*3]==204);
    if(square==63) for(int led:{64,65,73,74}) assert(out[2+(led-1)*3]==204);
  }
  memset(mask,255,8); certabo::spectrum::encode(mask,out);
  for(int led=0;led<81;++led) assert(out[2+led*3]==204); // no summed brightness
  memset(mask,0,8); certabo::spectrum::encode(mask,out);
  for(int i=2;i<245;++i) assert(out[i]==0);
  if(argc>1) {
    std::ifstream f(argv[1],std::ios::binary); assert(f.good());
    id.reset(); char c; while(f.get(c)) id.feed(static_cast<uint8_t>(c));
    assert(id.type()==LedType::Mono && !id.conflict());
  }
  puts("PASS: Spectrum 247-byte red80 frames, all 64 squares, PDF corners, passive identity, reconnect/conflict and mono capture");
}
