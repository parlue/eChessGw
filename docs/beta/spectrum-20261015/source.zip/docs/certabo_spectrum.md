# Spectrum LED backend (hardware verification pending)

The existing Certabo discovery, BLE connection, calibration, piece IDs and
King/Phoenix move logic are shared unchanged. `certabo_spectrum_leds.h` is the
separate Spectrum LED encoder; mono still sends its existing eight-byte mask.

Source: user's `RGB_Leds_chessboard_commands.pdf`: FF 55, 81 RGB triples,
0D 0A, total 247 bytes. Default RGB is (204, 0, 0), 80% red. LED 1 is at
the H1 outer corner, 9 at A1, 73 at H8 and 81 at A8. Adjacent squares share
corners without increasing brightness. Writes retain the existing ordered
MTU-3 fragmentation through the transparent NUS bridge.

Detection is passive, not based on MTU: standalone L selects mono, D selects
Spectrum/RGB. Tokens complete on CR/LF or the next position colon. Unknown or
conflicting identity sends **no LED commands**. Reset/reconnection discards
the identity; no model choice is persisted. Piece reception continues.

The recorded mono bridge emits L without probing. The PDF documents D as a
reply to an RGB frame, NOT as an unsolicited boot identifier. Thus automatic
Spectrum startup remains conditional on the bridge emitting D independently.
If it does not, capture Spectrum startup/GATT metadata and establish an explicit
read-only model signature before enabling LEDs. Never infer Spectrum from a
different negotiated MTU, silence, or timeout; never send a trial RGB frame to
an unidentified board. D is used as an RGB protocol marker, not claimed as a
unique commercial model identifier or per-command delivery acknowledgement.

No firmware upload is part of this preparation. Required physical checks:
mono startup/LED regression; Spectrum passive identification, calibration,
A1/H1/A8/H8 corner mapping, red brightness, all-off and King/Phoenix moves.
