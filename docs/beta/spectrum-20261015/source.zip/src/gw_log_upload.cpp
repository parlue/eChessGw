#include <NimBLEDevice.h>

#include "gw_log.h"
#include "gw_log_upload.h"
#include "gw_serial.h"  // keep last: Serial -> log-recording wrapper

namespace gwlog {

const char kTagName[] = "eChessGateway";

namespace {

const char kService[] = "e5c40000-6c4f-4a3b-9d2e-6b1a7f0c0001";
const char kLogChar[] = "e5c40001-6c4f-4a3b-9d2e-6b1a7f0c0001";
const char kCmdChar[] = "e5c40002-6c4f-4a3b-9d2e-6b1a7f0c0001";

portMUX_TYPE cmdMux = portMUX_INITIALIZER_UNLOCKED;
char cmdBuf[64];
size_t cmdLen = 0;

void onCommand(NimBLERemoteCharacteristic*, uint8_t* data, size_t length, bool) {
  portENTER_CRITICAL(&cmdMux);
  for (size_t i = 0; i < length && cmdLen < sizeof(cmdBuf) - 1; ++i) cmdBuf[cmdLen++] = static_cast<char>(data[i]);
  portEXIT_CRITICAL(&cmdMux);
}

// Write without response; the controller can be briefly full, so retry a few times.
bool sendBytes(NimBLERemoteCharacteristic* ch, const uint8_t* data, size_t length) {
  for (int attempt = 0; attempt < 20; ++attempt) {
    if (ch->writeValue(data, length, false)) return true;
    vTaskDelay(pdMS_TO_TICKS(15));
  }
  return false;
}

bool sendText(NimBLERemoteCharacteristic* ch, const char* text) {
  return sendBytes(ch, reinterpret_cast<const uint8_t*>(text), strlen(text));
}

// Pops one complete command line from cmdBuf, or returns false.
bool nextCommand(char* out, size_t outSize) {
  bool found = false;
  portENTER_CRITICAL(&cmdMux);
  for (size_t i = 0; i < cmdLen; ++i) {
    if (cmdBuf[i] == '\n') {
      size_t n = i < outSize - 1 ? i : outSize - 1;
      memcpy(out, cmdBuf, n);
      out[n] = 0;
      memmove(cmdBuf, cmdBuf + i + 1, cmdLen - i - 1);
      cmdLen -= i + 1;
      found = true;
      break;
    }
  }
  portEXIT_CRITICAL(&cmdMux);
  if (found) {  // strip a trailing CR
    size_t n = strlen(out);
    while (n > 0 && (out[n - 1] == '\r' || out[n - 1] == ' ')) out[--n] = 0;
  }
  return found;
}

}  // namespace

bool uploadTo(const NimBLEAddress& address) {
  Serial.printf("[GWLOG] tag found at %s -- uploading the stored log\r\n", address.toString().c_str());
  NimBLEClient* client = NimBLEDevice::createClient();
  client->setConnectTimeout(8000);
  client->setConnectionParams(12, 24, 0, 200);
  if (!client->connect(address)) {
    Serial.println("[GWLOG] connect to the tag app failed");
    NimBLEDevice::deleteClient(client);
    return false;
  }
  NimBLERemoteCharacteristic* logChar = nullptr;
  NimBLERemoteCharacteristic* cmdChar = nullptr;
  if (!client->getServices(true).empty()) {
    NimBLERemoteService* service = client->getService(kService);
    if (service) {
      logChar = service->getCharacteristic(kLogChar);
      cmdChar = service->getCharacteristic(kCmdChar);
    }
  }
  if (!logChar || !cmdChar) {
    Serial.println("[GWLOG] tag app has no log service");
    client->disconnect();
    NimBLEDevice::deleteClient(client);
    return false;
  }
  portENTER_CRITICAL(&cmdMux);
  cmdLen = 0;
  portEXIT_CRITICAL(&cmdMux);
  if (!cmdChar->canNotify() || !cmdChar->subscribe(true, onCommand)) {
    Serial.println("[GWLOG] could not subscribe to the tag app's command channel");
    client->disconnect();
    NimBLEDevice::deleteClient(client);
    return false;
  }

  const uint16_t mtu = client->getMTU();
  const size_t chunk = mtu > 23 ? (mtu - 3 < 180 ? mtu - 3 : 180) : 20;
  bool ok = true;
  {
    Reader reader;
    char header[112];
    snprintf(header, sizeof(header), "GWLOG1 %u rec=%d fw=%s up=%lu\n", static_cast<unsigned>(reader.totalBytes()),
             recording() ? 1 : 0, buildStamp(), static_cast<unsigned long>(millis()));
    ok = sendText(logChar, header);
    uint8_t buffer[180];
    size_t sent = 0;
    while (ok && client->isConnected()) {
      const size_t n = reader.read(buffer, chunk);
      if (n == 0) break;
      ok = sendBytes(logChar, buffer, n);
      sent += n;
      vTaskDelay(pdMS_TO_TICKS(10));  // pace the writes, the app's GATT server has small buffers
    }
    if (ok) ok = sendText(logChar, "\n#GWLOG-END\n");
    Serial.printf("[GWLOG] log upload %s (%u bytes sent)\r\n", ok ? "finished" : "failed", static_cast<unsigned>(sent));
  }

  // Commands from the app: it may switch recording on/off or delete the stored files.
  uint32_t until = millis() + 20000;
  while (ok && client->isConnected() && static_cast<int32_t>(millis() - until) < 0) {
    char cmd[32];
    if (nextCommand(cmd, sizeof(cmd))) {
      until = millis() + 10000;
      if (strcmp(cmd, "REC1") == 0) setRecording(true);
      else if (strcmp(cmd, "REC0") == 0) setRecording(false);
      else if (strcmp(cmd, "CLR") == 0) clearStored();
      else if (strcmp(cmd, "BYE") == 0) break;
      else continue;
      char reply[40];
      snprintf(reply, sizeof(reply), "#OK %s\n", cmd);
      sendText(logChar, reply);
    }
    vTaskDelay(pdMS_TO_TICKS(100));
  }
  client->disconnect();
  NimBLEDevice::deleteClient(client);
  return ok;
}

}  // namespace gwlog
