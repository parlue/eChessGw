#pragma once
#include "certabo_protocol.h"

namespace certabo {
// Passive identification only. Accept a standalone L/D token, not letters in
// diagnostics or damaged decimal position payloads. No MTU guesses/probes.
// A bare reply without CRLF is completed by the next ':' position delimiter.
class LedIdentity {
 public:
  void reset() { selected_=LedType::Unknown; conflict_=false; resetPending(); }
  void resetPending() { token_=0; length_=0; }
  void feed(uint8_t byte) {
    if (byte=='\r' || byte=='\n' || byte==':') {
      if (length_==1 && (token_=='L' || token_=='D')) {
        const LedType candidate=token_=='L' ? LedType::Mono : LedType::Rgb;
        if (selected_!=LedType::Unknown && selected_!=candidate) conflict_=true;
        else selected_=candidate;
      }
      resetPending();
      // ':' belongs to the position, so its content is never a marker token.
      if (byte==':') length_=2;
      return;
    }
    if (length_==0) token_=byte;
    if (length_<2) ++length_;
  }
  LedType type() const { return conflict_ ? LedType::Unknown : selected_; }
  bool conflict() const { return conflict_; }
 private:
  LedType selected_=LedType::Unknown;
  bool conflict_=false;
  uint8_t token_=0, length_=0;
};
}
