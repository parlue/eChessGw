@echo off

setlocal

cd /d "%~dp0"

call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul

if errorlevel 1 exit /b 1

cl /nologo /EHsc /std:c++17 /W4 /Iinclude test\chessnut_ble_leds_test.cpp /Fe:chessnut_ble_leds_test.exe /Fo:chessnut_ble_leds_test.obj

if errorlevel 1 exit /b 1

chessnut_ble_leds_test.exe
if errorlevel 1 exit /b 1
cl /nologo /EHsc /std:c++17 /W4 /Iinclude test\chessnut_ble_dispatch_test.cpp /Fe:chessnut_ble_dispatch_test.exe /Fo:chessnut_ble_dispatch_test.obj
if errorlevel 1 exit /b 1
chessnut_ble_dispatch_test.exe

