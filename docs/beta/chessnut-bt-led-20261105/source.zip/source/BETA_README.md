# eChessGw – Chessnut BT LED Beta 1

Stand: 5. November 2026. Zielhardware: ESP32-C3 SuperMini (bisheriges Gatewayprofil, 4 MB Flash).

## Umfang

Diese separate Beta korrigiert ausschließlich den Rückweg der ChessLink-BT-Maskierung auf Chessnut Air/Go/Pro: App-LED-Befehl -> Gateway -> Chessnut-Feld-LEDs.

- Eigenständiger BT-Einstieg; vollständige App-LED-Muster ersetzen die vorige Anzeige. Kein Phoenix-Zweifeldspeicher in diesem Weg.
- Ein zusätzliches Zwischenfeld wird bei einem generisch markierten Bauerndoppelschritt nur mit passender Brettstellung vor/nach dem Zug entfernt. Ohne passende Stellung bleibt das Muster erhalten.
- Kurze und lange Rochade mit Brettkontext; echte Turmfelder bleiben erhalten.
- Bei vorübergehendem Vorrang der lokalen Brettabweichung bleibt die Herkunft des zurückgestellten Befehls gespeichert. Auch ein neuer Leerbefehl ersetzt einen älteren Hinweis.
- King-/Phoenix-Kabeldispatcher, main.cpp, bestehende Koordinatenkonventionen, Brettstatus zur App und eingefrorene Versionen unverändert. Andere Bretttypen behalten ihren bisherigen Weg.
- Im Log erkennbar an `[CHESSNUT BT LED BETA1] decoded=3 resolved=2: c5 c7` (entsprechende Felder je Zug).

## Dateien und manuelles Flashen

- `eChessGw-Chessnut-BT-LED-Beta1-merged.bin`: zusammengeführtes Image, Adresse **0x0**.
- `firmware.bin`: nur die Anwendung, Adresse **0x10000**; nicht an 0x0 schreiben.
- Einzelteile: bootloader.bin an 0x0, partitions.bin an 0x8000, boot_app0.bin an 0xe000.
- `manifest.json`: vorbereitetes ESP-Web-Tools-Manifest für das zusammengeführte Image. Es wurde kein Webflasher veröffentlicht.
- `SHA256SUMS.txt`: Prüfsummen der ausgelieferten Dateien.
- Quellpaket und `changes.patch`: separate, nachvollziehbare Beta-Änderungen. Produktive Projektquellen wurden nicht überschrieben.

Es wurde kein angeschlossenes Gerät bedient oder geflasht. Hardwareprüfung bleibt beim Nutzer.

## Prüfergebnis

- ESP32-C3-Release erfolgreich gebaut: Platform Espressif32 7.0.1, Arduino-ESP32 2.0.17, NimBLE-Arduino 2.5.1, RISC-V GCC 8.4.0.
- Statischer RAM laut Linker: 79.572 / 327.680 Byte; Flash laut Linker: 740.364 / 1.310.720 Byte. Diese Angaben sind keine Laufzeit-Heap-Messung.
- 110 Normalisierungsfälle bestanden; 200 Fälle mit aus der Beta extrahiertem tatsächlichem Decoder, BT-Dispatcher, Zurückstellen und Wiederanwenden bestanden.
- Alle Linien und beide Farben, identische Wiederholungen, Vorher-/Nachherstellung, besetztes Zwischenfeld, fehlender Brettkontext, Rollenmarkierungen, Springerzug, Leerbefehl, Reset-/Mehrfeldmasken und vier Rochaden geprüft.
- Verzögerter BT-Befehl kehrt in den BT-Weg zurück; ein verzögerter Legacy-Befehl weiterhin in den bisherigen Weg. Andere Bretttypen behalten den bisherigen Dispatcher.
- Der ursprüngliche Fehler wurde vor der Korrektur in einem isolierten C++-Test reproduziert: c5/c6/c7 wurde je nach Speicherzustand zu c7 oder c6/c7.
- Originalquellen gegen ihre vor Beginn gesicherten SHA-256-Werte geprüft. Der bestehende board_driver.cpp-Code ist bis auf den neuen Header-Include unverändert, der neue BT-Handler ist angehängt. main.cpp ist bytegleich.
- Merged-Image an allen vier Teilimage-Adressen byteweise geprüft; ESP-Image-Checksumme und Validierungshash korrekt.

## Test am Brett

1. Chessnut per BT mit dem Gateway verbinden, App mit dessen ChessLink-Maskierung verbinden.
2. Eigene Doppelschritte beobachten; bei einem Engine-Doppelschritt müssen vor dem Anheben Start und Ziel erhalten bleiben, ohne zusätzliches Zwischenfeld.
3. Insbesondere c7-c5 oder e7-e5 prüfen, sobald die App diesen Zug vorgibt. Nach Anheben kann die App berechtigt nur noch das Zielfeld markieren.
4. Springerzug, normale Bauernzüge, Schlagen und Rochade prüfen; nach Ausführung darf kein alter Hinweis hängenbleiben.
5. Im Log auf den neuen BETA1-Marker und die aufgelösten Felder achten. Derselbe unveränderte Befehl soll dieselbe Feldauswahl liefern.

Mehrdeutige Eckmuster lassen sich grundsätzlich nicht immer eindeutig zurückrechnen. Diese Beta verwendet gezielt die aktuelle Brettstellung für Doppelschritte und Rochaden. Sie ist noch nicht an realer Hardware bestätigt. Der bestehende Kabelweg wurde quellseitig erhalten, aber nicht am Gerät erneut geprüft.

## Quellen bauen

Im entpackten Quellpaket: `pio run -e esp32-c3-supermini_ChessnutBtLedBeta`.
Die explizite Beta-Umgebung verwenden, nicht die bisherige Standardumgebung. Abhängigkeiten sind auf die beim Build benutzten Versionen festgelegt.
`test_beta.cmd` führt die beiden Windows-Konsolentests mit den vorhandenen Visual Studio 2022 Build Tools aus.
