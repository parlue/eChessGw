#include <cassert>
#include <cstdio>
#include <cstring>
#include "chessnut_ble_leds.h"
uint64_t bit(int f,int r){return uint64_t(1)<<((r-1)*8+f);}
void empty(char* b){std::memset(b,'.',64);}
int main(){
 char b[64]; int cases=0;
 for(int side=0;side<2;++side) for(int f=0;f<8;++f){
  const int from=side?7:2, mid=side?6:3, to=side?5:4;
  const uint64_t ends=bit(f,from)|bit(f,to), three=ends|bit(f,mid);
  empty(b);b[(from-1)*8+f]=side?'p':'P';
  assert(chessnut_ble::normalize(three,three,b)==ends);++cases;
  for(int i=0;i<10;++i) assert(chessnut_ble::normalize(three,three,b)==ends);
  b[(from-1)*8+f]='.';b[(to-1)*8+f]=side?'p':'P';
  assert(chessnut_ble::normalize(three,three,b)==ends);++cases;
  b[(mid-1)*8+f]='N'; assert(chessnut_ble::normalize(three,three,b)==three);++cases;
  empty(b);assert(chessnut_ble::normalize(three,three,b)==three);++cases;
  b[(from-1)*8+f]=side?'p':'P';
  assert(chessnut_ble::normalize(three,0,b)==three);++cases;
  assert(chessnut_ble::normalize(ends,ends,b)==ends);++cases;
 }
 for(int side=0;side<2;++side) for(int queen=0;queen<2;++queen){
  const int base=side?56:0, rook=queen?0:7, kt=queen?2:6, rt=queen?3:5;
  const char k=side?'k':'K',r=side?'r':'R';
  const uint64_t exact=(uint64_t(1)<<(base+4))|(uint64_t(1)<<(base+rook))|
                       (uint64_t(1)<<(base+kt))|(uint64_t(1)<<(base+rt));
  const uint64_t raw=exact|(queen ? uint64_t(1)<<(base+1) : 0);
  empty(b);b[base+4]=k;b[base+rook]=r;
  assert(chessnut_ble::normalize(raw,raw,b)==exact);++cases;
  b[base+4]='.';b[base+rook]='.';b[base+kt]=k;b[base+rt]=r;
  assert(chessnut_ble::normalize(raw,raw,b)==exact);++cases;
 }
 empty(b);const uint64_t knight=bit(6,8)|bit(5,6);
 assert(chessnut_ble::normalize(knight,knight,b)==knight);++cases;
 assert(chessnut_ble::normalize(0,0,b)==0);++cases;
 const uint64_t reset=0xffff00000000ffffULL;
 assert(chessnut_ble::normalize(reset,reset,b)==reset);++cases;
 assert(chessnut_ble::normalize(~uint64_t(0),~uint64_t(0),b)==~uint64_t(0));++cases;
 const uint64_t unknown=bit(2,5)|bit(2,6)|bit(2,7);
 assert(chessnut_ble::normalize(unknown,unknown,nullptr)==unknown);++cases;
 assert(chessnut_ble::normalize(unknown,unknown,b)==unknown);++cases;
 std::printf("PASS: %d normalization cases; repeated frames deterministic.\n",cases);
}
