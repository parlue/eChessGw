
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <cassert>
#include <initializer_list>
#include "chessnut_ble_leds.h"
enum class BoardType:uint8_t{Chessnut,Millennium};
enum class SquareHighlightRole:uint8_t{Generic,Source,Destination};
enum class ChessnutLedOrigin:uint8_t{LegacyHost,ChesslinkBle};
struct SquareHighlight{uint8_t squareIndex;SquareHighlightRole role;};
constexpr int boardSquareIndex(char f,int r){return (r-1)*8+f-'a';}
constexpr int modeBStatusWireIndex(int f,int r){return (r-1)*8+7-f;}
uint8_t ledGrid[81],status[67],deferredLedFrame[167];
bool haveDeferredLedFrame=false,localDeviation=false;
ChessnutLedOrigin deferredLedOrigin=ChessnutLedOrigin::LegacyHost;
uint64_t displayed=0;int legacyCalls=0;
struct Log{template<class... T>void printf(const char*,T...){}void println(){}} Serial;
const uint8_t* cachedBoardStatusBytes(){return status;}
bool chessnutHasLocalDeviation(){return localDeviation;}
void chessnutShowLocalBoardDeviations(){}
void chessnutSetHighlightedSquares(const SquareHighlight* s,size_t n){displayed=0;for(size_t i=0;i<n;++i)displayed|=uint64_t(1)<<s[i].squareIndex;}
void dispatchLedFrameToBoard(BoardType,const uint8_t*){++legacyCalls;}
void dispatchChesslinkBleLedFrameToBoard(BoardType,const uint8_t*);
void chessnutDeferLedFrame(const uint8_t*,ChessnutLedOrigin=ChessnutLedOrigin::LegacyHost);
size_t decodeKingLedFrame(const uint8_t frame167[167], SquareHighlight* out, size_t maxOut) {
  auto hexNibble = [](uint8_t c) -> int {
    c &= 0x7f;
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
  };
  for (int i = 0; i < 81; ++i) {
    const int hi = hexNibble(frame167[3 + i * 2]);
    const int lo = hexNibble(frame167[4 + i * 2]);
    if (hi < 0 || lo < 0) return 0;
    ledGrid[i] = static_cast<uint8_t>((hi << 4) | lo);
  }

  // Covers both a 1-2 square move suggestion (source/destination markers)
  // and a many-square "these pieces need to go back" New Game/reset frame.
  //
  // Two highlighted squares that are grid-adjacent share one or more of
  // their 4 corners; a shared corner carries BOTH squares' marker bits at
  // once (0x0F | 0xF0 = 0xFF), so requiring all 4 corners to be byte-
  // identical (as an earlier version of this function did) fails for both
  // squares whenever they're adjacent -- confirmed against a real King
  // capture (active-values=6, corner pattern F0 FF 0F) that produced no
  // highlight at all under the strict check. Instead, a square counts as
  // marked with a given role if EVERY one of its 4 corners carries that
  // role's bit (0x0F for source, 0xF0 for destination) -- true even for a
  // shared corner, since 0xFF still contains both bits.
  size_t count = 0;
  for (int file = 0; file < 8; ++file) {
    for (int rankTop = 0; rankTop < 8; ++rankTop) {
      const uint8_t c00 = ledGrid[file * 9 + rankTop];
      const uint8_t c10 = ledGrid[(file + 1) * 9 + rankTop];
      const uint8_t c01 = ledGrid[file * 9 + rankTop + 1];
      const uint8_t c11 = ledGrid[(file + 1) * 9 + rankTop + 1];
      const bool allLit = c00 != 0 && c10 != 0 && c01 != 0 && c11 != 0;
      if (!allLit) continue;
      const bool allHaveSourceBit =
          (c00 & 0x0F) && (c10 & 0x0F) && (c01 & 0x0F) && (c11 & 0x0F);
      const bool allHaveDestBit =
          (c00 & 0xF0) && (c10 & 0xF0) && (c01 & 0xF0) && (c11 & 0xF0);
      if (!allHaveSourceBit && !allHaveDestBit) continue;

      if (count < maxOut) {
        // File order on the wire is reversed (h..a) -- confirmed for King
        // via three independent real captures, and now also confirmed for
        // Mephisto Phoenix via two real move captures (e2-e4 and c7-c5,
        // both mirrored without this correction). Same convention for both.
        const int changedFile = 7 - file;  // 0-based a..h
        const int changedRank = rankTop + 1;
        out[count].squareIndex = static_cast<uint8_t>(
            boardSquareIndex(static_cast<char>('a' + changedFile), changedRank));
        if (allHaveSourceBit && !allHaveDestBit) {
          out[count].role = SquareHighlightRole::Source;
        } else if (allHaveDestBit && !allHaveSourceBit) {
          out[count].role = SquareHighlightRole::Destination;
        } else {
          out[count].role = SquareHighlightRole::Generic;
        }
      }
      ++count;
    }
  }
  return count < maxOut ? count : maxOut;
}

void chessnutDeferLedFrame(const uint8_t frame167[167], ChessnutLedOrigin origin) {
  deferredLedOrigin = origin;
  memcpy(deferredLedFrame, frame167, sizeof(deferredLedFrame));
  haveDeferredLedFrame = true;
}

void settleReplay(){
        if (deferredLedOrigin == ChessnutLedOrigin::ChesslinkBle)
          dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut, deferredLedFrame);
        else
          dispatchLedFrameToBoard(BoardType::Chessnut, deferredLedFrame);
}
void dispatchChesslinkBleLedFrameToBoard(BoardType type, const uint8_t frame167[167]) {
  if (type != BoardType::Chessnut) {
    dispatchLedFrameToBoard(type, frame167);
    return;
  }
  SquareHighlight squares[64];
  const size_t decoded = decodeKingLedFrame(frame167, squares, 64);
  uint64_t fields=0, generic=0;
  for (size_t i=0; i<decoded; ++i) {
    const uint64_t bit=uint64_t(1)<<squares[i].squareIndex;
    fields |= bit;
    if (squares[i].role==SquareHighlightRole::Generic) generic |= bit;
  }
  char board[64];
  const uint8_t* cached=cachedBoardStatusBytes();
  if (cached) for (int s=0; s<64; ++s)
    board[s]=static_cast<char>(cached[1+modeBStatusWireIndex(s%8,s/8+1)]);
  const uint64_t resolved=chessnut_ble::normalize(fields,generic,cached ? board : nullptr);
  size_t count=0;
  for (int s=0; s<64; ++s) if ((resolved>>s)&1u)
    squares[count++]={static_cast<uint8_t>(s),SquareHighlightRole::Generic};
  Serial.printf("[CHESSNUT BT LED BETA1] decoded=%u resolved=%u:",
                static_cast<unsigned>(decoded),static_cast<unsigned>(count));
  for (size_t i=0; i<count; ++i)
    Serial.printf(" %c%d",'a'+squares[i].squareIndex%8,squares[i].squareIndex/8+1);
  Serial.println();
  if (chessnutHasLocalDeviation()) {
    chessnutDeferLedFrame(frame167,ChessnutLedOrigin::ChesslinkBle);
    chessnutShowLocalBoardDeviations();
  } else {
    // One complete app frame replaces the previous display, including clear.
    // Never enter the legacy Phoenix two-square accumulator.
    chessnutSetHighlightedSquares(count ? squares : nullptr,count);
  }
}


uint64_t bit(int f,int r){return uint64_t(1)<<((r-1)*8+f);}
void makeFrame(uint8_t* frame,uint64_t fields){
 uint8_t grid[81]={};for(int q=0;q<64;++q)if((fields>>q)&1u){int col=7-q%8,r=q/8;
  grid[col*9+r]|=0xff;grid[(col+1)*9+r]|=0xff;grid[col*9+r+1]|=0xff;grid[(col+1)*9+r+1]|=0xff;}
 std::memset(frame,'0',167);frame[0]='L';frame[2]='1';const char* h="0123456789ABCDEF";
 for(int i=0;i<81;++i){frame[3+2*i]=h[grid[i]>>4];frame[4+2*i]=h[grid[i]&15];}
}
void boardEmpty(){std::memset(status,'.',67);status[0]='s';}
void piece(int f,int r,char c){status[1+modeBStatusWireIndex(f,r)]=static_cast<uint8_t>(c);}
int main(){
 uint8_t frame[167],clear[167];makeFrame(clear,0);int cases=0;
 for(int side=0;side<2;++side)for(int f=0;f<8;++f){
  int from=side?7:2,to=side?5:4;const char pawn=side?'p':'P';
  uint64_t ends=bit(f,from)|bit(f,to);boardEmpty();piece(f,from,pawn);makeFrame(frame,ends);
  for(int i=0;i<10;++i){dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,frame);assert(displayed==ends);++cases;}
  // A deferred BT command must retain the explicit BT origin through settling.
  localDeviation=true;dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,frame);
  assert(haveDeferredLedFrame&&deferredLedOrigin==ChessnutLedOrigin::ChesslinkBle);
  piece(f,from,'.');piece(f,to,pawn);localDeviation=false;settleReplay();assert(displayed==ends);++cases;
  // A newer deferred clear supersedes the old non-empty hint.
  localDeviation=true;dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,frame);
  dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,clear);localDeviation=false;settleReplay();assert(displayed==0);++cases;
 }
 boardEmpty();makeFrame(frame,bit(6,8)|bit(5,6));dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,frame);
 assert(displayed==(bit(6,8)|bit(5,6)));++cases;
 dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,clear);assert(displayed==0);++cases;
 for(int black=0;black<2;++black)for(int queen=0;queen<2;++queen){
  const int rank=black?8:1;boardEmpty();piece(4,rank,black?'k':'K');piece(queen?0:7,rank,black?'r':'R');
  const uint64_t fields=bit(4,rank)|bit(queen?0:7,rank)|bit(queen?2:6,rank)|bit(queen?3:5,rank);
  makeFrame(frame,fields);dispatchChesslinkBleLedFrameToBoard(BoardType::Chessnut,frame);assert(displayed==fields);++cases;
 }
 assert(legacyCalls==0);chessnutDeferLedFrame(clear);assert(deferredLedOrigin==ChessnutLedOrigin::LegacyHost);settleReplay();assert(legacyCalls==1);++cases;
 dispatchChesslinkBleLedFrameToBoard(BoardType::Millennium,clear);assert(legacyCalls==2);++cases;
 std::printf("PASS: %d actual-code dispatch/codec/deferred-origin cases.\n",cases);
}
