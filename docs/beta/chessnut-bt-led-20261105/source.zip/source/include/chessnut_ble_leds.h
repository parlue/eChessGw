#pragma once
#include <stdint.h>
#include "certabo_castling.h"

// Only for ChessLink BLE masquerade -> Chessnut. No cable call sites.
namespace chessnut_ble {
inline uint64_t normalize(uint64_t fields, uint64_t generic, const char* board) {
  if (!board || !fields) return fields;
  // Canonical four-square castling display, using position context rather
  // than deleting arbitrary middle squares (which could be rook destinations).
  uint64_t castle = certabo::castlingMask(fields, board);
  if (castle) return castle;
  struct Castle { int king, rook, toKing, toRook; char k, r; };
  static const Castle castles[] = {{4,0,2,3,'K','R'}, {4,7,6,5,'K','R'},
                                   {60,56,58,59,'k','r'}, {60,63,62,61,'k','r'}};
  for (const auto& c : castles) {
    const int lo = c.king < c.rook ? c.king : c.rook;
    const int hi = c.king < c.rook ? c.rook : c.king;
    uint64_t run = 0;
    for (int s=lo; s<=hi; ++s) run |= uint64_t(1)<<s;
    const uint64_t exact = (uint64_t(1)<<c.king)|(uint64_t(1)<<c.rook)|
                           (uint64_t(1)<<c.toKing)|(uint64_t(1)<<c.toRook);
    if ((fields & ~run) || !(fields & (uint64_t(1)<<c.king)) ||
        certabo::popcount64(fields & exact)<3) continue;
    if (board[c.king]!='.' || board[c.rook]!='.' ||
        board[c.toKing]!=c.k || board[c.toRook]!=c.r) continue;
    bool clear = true;
    for (int s=lo; s<=hi; ++s)
      if (s!=c.toKing && s!=c.toRook && board[s]!='.') clear=false;
    if (clear) return exact;
  }
  // Ambiguous three-square patterns are reduced ONLY for a pawn double
  // push from its home rank, with an empty middle and valid before/after
  // occupancy. Other triples, role-marked squares and reset displays survive.
  if (fields != generic || certabo::popcount64(fields)!=3) return fields;
  for (int f=0; f<8; ++f) {
    for (int side=0; side<2; ++side) {
      const int from=(side ? 6 : 1)*8+f, middle=(side ? 5 : 2)*8+f;
      const int to=(side ? 4 : 3)*8+f;
      const char pawn=side ? 'p' : 'P';
      const uint64_t ends=(uint64_t(1)<<from)|(uint64_t(1)<<to);
      if (fields != (ends|(uint64_t(1)<<middle)) || board[middle]!='.') continue;
      const bool before=board[from]==pawn && board[to]=='.';
      const bool after=board[from]=='.' && board[to]==pawn;
      if (before || after) return ends;
    }
  }
  return fields;
}
} // namespace chessnut_ble
